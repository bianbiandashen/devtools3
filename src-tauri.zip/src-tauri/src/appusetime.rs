use tauri::Manager;
use std::time::{Duration, SystemTime};
use std::collections::HashMap;

struct AppUsage {
    start_time: SystemTime,
    duration: Duration,
}

impl AppUsage {
    fn new() -> Self {
        Self {
            start_time: SystemTime::now(),
            duration: Duration::new(0, 0),
        }
    }

    fn update_duration(&mut self) {
        self.duration = SystemTime::now().duration_since(self.start_time).unwrap();
    }
}

#[tauri::command]
pub fn get_app_usage() -> HashMap<String, u64> {
    let mut usage = HashMap::new();

    // 模拟数据
    usage.insert("WeChat".to_string(), 3600); // 1小时
    usage.insert("VSCode".to_string(), 7200); // 2小时
    usage.insert("Chrome".to_string(), 5400); // 1.5小时

    usage
}
