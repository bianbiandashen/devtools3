use log::{info, error};
use simplelog::*;
use std::env;
use std::fs::{self, File};
use std::path::PathBuf;
use tauri::{AppHandle, CustomMenuItem, Manager, SystemTray, SystemTrayEvent, SystemTrayMenu, SystemTrayMenuItem};
use tokio::runtime::Runtime;
use std::process::Command;
use chrono::offset::FixedOffset;
use std::os::unix::fs::PermissionsExt;
use dirs_next::home_dir;

mod appusetime;
mod commands;
mod proxy;
mod port;
mod websocket;

fn main() {
    // 确定日志文件路径
    let is_dev = env::var("TAURI_DEV").is_ok();
    let timezone_offset = 8 * 3600; // UTC+8
    let timezone = FixedOffset::east(timezone_offset);

    info!("Application started");

    // 定义托盘菜单项
    let quit = CustomMenuItem::new("quit", "退出");
    let disable_proxy_item = CustomMenuItem::new("disable_proxy_item", "一键关闭代理");

    // 创建托盘菜单
    let tray_menu = SystemTrayMenu::new()
        .add_item(disable_proxy_item.clone())
        .add_native_item(SystemTrayMenuItem::Separator)
        .add_item(quit.clone());

    // 创建系统托盘
    let tray = SystemTray::new().with_menu(tray_menu);

    // 创建 Tokio 运行时
    let rt = Runtime::new().expect("Failed to create runtime");

    tauri::Builder::default()
        .system_tray(tray)
        .setup(move |app| {
            info!("Setup started");

            // 判断当前的架构并使用对应的 Node.js 版本
            let is_dev = env::var("TAURI_DEV").is_ok();
            let arch = env::var("ARCH").unwrap_or_else(|_| "x64".to_string());
            let node_dir = if is_dev {
                "binaries/node-v16.20.2-darwin-x64/bin/node"
            } else if arch == "arm64" || arch == "aarch64" {
                // Apple M1 (ARM) 的路径
                "/Applications/smart-workbench.app/Contents/Resources/binaries/node-v16.20.2-darwin-arm64/bin/node"
            } else {
                // Intel Mac (x64) 的路径
                "/Applications/smart-workbench.app/Contents/Resources/binaries/node-v16.20.2-darwin-x64/bin/node"
            };

            // 确保 Node.js 可执行文件具有执行权限
            if let Err(e) = fs::set_permissions(node_dir, fs::Permissions::from_mode(0o755)) {
                eprintln!("Failed to set permissions for {}: {}", node_dir, e);
            }

            // 运行 Node.js
            let output = Command::new(node_dir)
                .arg("--version")
                .output()
                .expect("Failed to execute Node.js");
            info!("Node.js version: {:?}", output);


            #[cfg(debug_assertions)] // only include this code on debug builds
            {
                let handle = app.handle();

                // 注册全局事件监听器
                handle.listen_global("command-output", move |event| {
                    if let Some(payload) = event.payload() {
                        println!("Event received: {:?}", payload);
                    } else {
                        println!("No payload in event");
                    }
                });

                // 启动 WebSocket 服务器
                // rt.spawn(async move {
                //     start_websocket_server("127.0.0.1:9001", handle).await;
                // });

                // 启用代理
            }
            Ok(())
        })
        .on_system_tray_event(move |app, event| match event {
            SystemTrayEvent::MenuItemClick { id, .. } => match id.as_str() {
                "quit" => std::process::exit(0),
                "disable_proxy_item" => proxy::disable_proxy(),
                _ => {}
            },
            _ => {}
        })
        .invoke_handler(tauri::generate_handler![
            commands::exec_spawn_command,
            commands::read_package_json_files,
            commands::save_path_config,
            commands::read_path_config_cache,
            commands::clear_path_config_cache,
            commands::is_proxy_enabled,
            commands::create_temp_file_with_list,
            commands::read_temp_file,
            commands::get_current_dir,
            commands::open_in_vscode,
            commands::install_node_npm,
            commands::install_homebrew,
            commands::read_redpass_config_file,
            commands::check_devtool_config_exists,
            commands::install_modular_startup,
            commands::exec_spawn_command_by_port,
            commands::kill_process_by_id,
            appusetime::get_app_usage,
            port::check_port,
            port::close_port_7777,
            port::close_established_connections_on_port,
            proxy::disable_proxy,
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
