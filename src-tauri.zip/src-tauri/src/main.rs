use simplelog::*;
use reqwest;
use std::env;
use std::str;
use std::fs::{self, File};
use std::path::PathBuf;
use tauri::{AppHandle, CustomMenuItem, Manager, SystemTray, SystemTrayEvent, SystemTrayMenu, SystemTrayMenuItem};
use tokio::runtime::Runtime;
use std::process::Command;
use log::{info, error}; // 导入log宏

mod commands;
mod proxy;
mod port;
mod websocket;

// fn run_with_sudo(command: &str) -> Result<(), String> {
//     let applescript = format!(
//         r#"do shell script "{}" with administrator privileges"#,
//         command
//     );

//     let output = Command::new("osascript")
//         .arg("-e")
//         .arg(applescript)
//         .output()
//         .map_err(|e| format!("Failed to execute osascript: {}", e))?;

//     if !output.status.success() {
//         let stderr = String::from_utf8_lossy(&output.stderr);
//         return Err(format!("Command failed: {}", stderr));
//     }

//     Ok(())
// }

#[tauri::command]
fn greet(name: &str) -> String {
    format!("Hello, {}! You've been greeted from Rust!", name)
}

#[tauri::command]
async fn node_hello_express() -> Result<String, String> {
    println!("start request",);
    let resp = reqwest::get("http://localhost:3000/")
        .await
        .map_err(|e| format!("Failed to write to temp file: {}", e))?;
    println!(
        "Response: {:?}",
        resp.text()
            .await
            .map_err(|e| format!("Failed to write to temp file: {}", e))?
    );
    Ok("Hello! You've been greeted from Rust!".to_string())
}

#[tauri::command]
async fn check_app_update() -> Result<String, String> {
    println!("start check app update",);
    let resp = reqwest::get("http://localhost:3000/checkUpdate")
        .await
        .map_err(|e| format!("Failed to write to temp file: {}", e))?;
    println!(
        "Response: {:?}",
        resp.text()
            .await
            .map_err(|e| format!("Failed to write to temp file: {}", e))?
    );
    Ok("hello".to_string())
}

static NODE_DIR_STR: &str = "node/bin/node";
fn main() {


    // let install_dir = "/Volumes/smart-workbench/smart-workbench.app";

    // // 切换到指定目录
    // std::env::set_current_dir(install_dir)
    //     .expect(&format!("Failed to change directory to {}", install_dir));

    // // 运行 Homebrew 安装命令
    // run_with_sudo("brew install node").expect("Failed to install Node.js and npm");

    // // 运行 npm 安装命令
    // run_with_sudo("npm install -g @xhs/modular-startup").expect("Failed to install @xhs/modular-startup");

    // 定义托盘菜单项
    let quit = CustomMenuItem::new("quit", "退出");
    let disable_proxy_item = CustomMenuItem::new("disable_proxy_item", "一键关闭代理");

    // 创建托盘菜单
    let tray_menu = SystemTrayMenu::new()
        .add_item(disable_proxy_item.clone())
        .add_native_item(SystemTrayMenuItem::Separator)
        .add_item(quit.clone());

    // 创建系统托盘
    let tray = SystemTray::new().with_menu(tray_menu);

    // 创建 Tokio 运行时
    let rt = Runtime::new().expect("Failed to create runtime");

    // 获取用户的应用支持目录
    let mut log_path = PathBuf::from("/Users/bianlian/Library");
    fs::create_dir_all(&log_path).unwrap();
    log_path.push("log_file.log");

    // Further code to work with log_path
    // Example: create the log file
    fs::File::create(&log_path).unwrap();

    // 设置日志配置
    WriteLogger::init(
        LevelFilter::Info,
        Config::default(),
        File::create(log_path).unwrap(),
    ).unwrap();

    let command_output = Command::new(NODE_DIR_STR)
    .arg("-v")
    .output()
    .expect("Failed to execute Node.js command");

    let stdout = str::from_utf8(&command_output.stdout).unwrap();
    let stderr = str::from_utf8(&command_output.stderr).unwrap();
    if command_output.status.success() {
        println!("Node.js version: {}", stdout);
        // // 更新 PATH 环境变量以包含 node 二进制目录
        let path = env::var("PATH").unwrap();
        let new_path = format!("{}:{}", NODE_DIR_STR, path);
        env::set_var("PATH", &new_path);
    //         println!("Updated PATH: {}", new_path.clone());
    } else {
        println!("Error: {}", stderr);
    }

    tauri::Builder::default()
        .system_tray(tray)
        .setup(move |app| {
            info!("This is an info message");
            error!("This is an error message");
            info!("This is a warning message");
            // 启动Node.js服务器
            Command::new(NODE_DIR_STR)
            .arg("node/server.js")
            .spawn()
            .expect("Failed to start server");
            #[cfg(debug_assertions)] // only include this code on debug builds
            {
                let handle = app.handle();

                // 注册全局事件监听器
                handle.listen_global("command-output", move |event| {
                    if let Some(payload) = event.payload() {
                        println!("Event received: {:?}", payload);
                    } else {
                        println!("No payload in event");
                    }
                });

                // 启动 WebSocket 服务器
                // rt.spawn(async move {
                //     start_websocket_server("127.0.0.1:9001", handle).await;
                // });

                // 启用代理
            }
            Ok(())
        })
        .on_system_tray_event(move |app, event| match event {
            SystemTrayEvent::MenuItemClick { id, .. } => match id.as_str() {
                "quit" => std::process::exit(0),
                "disable_proxy_item" => proxy::disable_proxy(),
                _ => {}
            },
            _ => {}
        })
        .invoke_handler(tauri::generate_handler![
            commands::exec_spawn_command,
            commands::read_package_json_files,
            commands::save_path_config,
            commands::read_path_config_cache,
            commands::clear_path_config_cache,
            commands::is_proxy_enabled,
            commands::create_temp_file_with_list,
            commands::read_temp_file,
            commands::get_current_dir,
            commands::open_in_vscode,
            commands::install_node_npm,
            commands::install_homebrew,
            commands::read_redpass_config_file,
            commands::check_devtool_config_exists,
            commands::install_modular_startup,

            port::check_port,
            port::close_port_7777,
            port::close_established_connections_on_port,
            proxy::disable_proxy,
            greet,
            node_hello_express,
            check_app_update
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
