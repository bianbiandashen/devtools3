use tauri::{AppHandle, Manager};
use std::process::{Command, Stdio};
use std::io::BufRead;
use std::io::Write;
use std::fs::File;
use std::path::Path;
use std::fs;
use serde_json::Value;
use sysinfo::{ProcessExt, System, SystemExt};
use serde::Serialize;

#[derive(Serialize)]
pub struct PortInfo {
    pid: i32,
    working_directory: String,
}

/// 获取监听特定端口的进程 ID
fn get_pid_by_port(port: u16) -> Option<i32> {
    let output = Command::new("lsof")
        .arg("-i")
        .arg(format!(":{}", port))
        .arg("-t")
        .output()
        .expect("Failed to execute lsof command");

    if output.status.success() {
        let pid_str = String::from_utf8_lossy(&output.stdout).trim().to_string();
        if !pid_str.is_empty() {
            return pid_str.parse::<i32>().ok();
        }
    }
    None
}

/// 获取进程的工作目录
fn get_working_directory(pid: i32) -> Option<String> {
    let output = Command::new("lsof")
        .arg("-p")
        .arg(pid.to_string())
        .output()
        .expect("Failed to execute lsof command");

    if output.status.success() {
        let output_str = String::from_utf8_lossy(&output.stdout);
        for line in output_str.lines() {
            if line.contains("cwd") {
                let parts: Vec<&str> = line.split_whitespace().collect();
                if let Some(dir) = parts.last() {
                    return Some(dir.to_string());
                }
            }
        }
    }
    None
}

#[tauri::command]
pub fn check_port() -> Result<Option<PortInfo>, String> {
    let port = 7777;

    // 获取监听端口的进程 ID
    if let Some(pid) = get_pid_by_port(port) {
        println!("Process ID listening on port {}: {}", port, pid);

        // 获取进程的工作目录
        if let Some(working_directory) = get_working_directory(pid) {
            println!("Working directory of process {}: {}", pid, working_directory);
            return Ok(Some(PortInfo { pid, working_directory }));
        } else {
            println!("Failed to get working directory of process {}", pid);
            return Err(format!("Failed to get working directory of process {}", pid));
        }
    } else {
        println!("No process is listening on port {}", port);
        return Ok(None);
    }
}


#[tauri::command]
pub fn close_port_7777() -> Result<String, String> {
    let output = Command::new("sh")
        .arg("-c")
        .arg("lsof -t -i:7777 | xargs kill -9")
        .output()
        .map_err(|e| e.to_string())?;

    if output.status.success() {
        let killed_pids = String::from_utf8_lossy(&output.stdout).to_string();
        Ok(format!("Killed PIDs: {}", killed_pids))
    } else {
        Err("Failed to close port 7777".into())
    }
}

#[tauri::command]
pub fn close_established_connections_on_port(port: u16) -> Result<String, String> {
    // 构建命令字符串
    let command_string = format!("lsof -i tcp:{} -Fp | grep -i 'p' | cut -c 2-", port);
    println!("Executing command: {}", command_string);

    // 执行命令
    let output = Command::new("sh")
        .arg("-c")
        .arg(&command_string)
        .output()
        .map_err(|e| {
            println!("Failed to execute command: {}", e);
            e.to_string()
        })?;

    if output.status.success() {
        let pids = String::from_utf8_lossy(&output.stdout);
        let pids: Vec<&str> = pids.split_whitespace().collect();
        let pid_count = pids.len();

        println!("Found {} established connections with PIDs: {:?}", pid_count, pids);

        if pid_count == 0 {
            return Ok("No established connections found on the port".to_string());
        }

        let kill_command = format!("echo {} | xargs kill -9", pids.join(" "));
        println!("Executing kill command: {}", kill_command);

        let kill_output = Command::new("sh")
            .arg("-c")
            .arg(&kill_command)
            .output()
            .map_err(|e| e.to_string())?;

        if kill_output.status.success() {
            let killed_pids = String::from_utf8_lossy(&kill_output.stdout).to_string();
            println!("Successfully killed PIDs: {:?}", pids);
            Ok(format!("Killed PIDs: {}", killed_pids))
        } else {
            let stderr = String::from_utf8_lossy(&kill_output.stderr).to_string();
            println!("Failed to kill PIDs, stderr: {}", stderr);
            Err(format!("Failed to kill established connections on port: {}", stderr))
        }
    } else {
        let stderr = String::from_utf8_lossy(&output.stderr).to_string();
        println!("Failed to find established connections, stderr: {}", stderr);
        Err(format!("Failed to find established connections on port: {}", stderr))
    }
}


