# @xhs/modular-webui

## 2.18.0

### Minor Changes

- 增加 proxy 证书能力

## 2.17.0

### Minor Changes

- preview

### Patch Changes

- Updated dependencies
  - @xhs/modular-rpc@1.18.0

## 2.16.0

### Minor Changes

- rpc bug

### Patch Changes

- Updated dependencies
  - @xhs/modular-rpc@1.17.0

## 2.15.0

### Minor Changes

- changelogs

### Patch Changes

- Updated dependencies
  - @xhs/modular-rpc@1.16.0

## 2.14.0

### Minor Changes

- fix

### Patch Changes

- Updated dependencies
  - @xhs/modular-rpc@1.15.0

## 2.13.0

### Minor Changes

- changelogs

### Patch Changes

- Updated dependencies
  - @xhs/modular-rpc@1.14.0

## 2.12.0

### Minor Changes

- 绿色调试点的问题

### Patch Changes

- Updated dependencies
  - @xhs/modular-rpc@1.13.0

## 2.11.0

### Minor Changes

- test

### Patch Changes

- Updated dependencies
  - @xhs/modular-rpc@1.12.0

## 2.10.0

### Minor Changes

- rpc bug

### Patch Changes

- Updated dependencies
  - @xhs/modular-rpc@1.11.0

## 2.9.0

### Minor Changes

- check rpc

### Patch Changes

- Updated dependencies
  - @xhs/modular-rpc@1.10.0

## 2.8.0

### Minor Changes

- check

### Patch Changes

- Updated dependencies
  - @xhs/modular-rpc@1.9.0

## 2.7.0

### Minor Changes

- main-fix

### Patch Changes

- Updated dependencies
  - @xhs/modular-rpc@1.8.0

## 2.6.0

### Minor Changes

- feat-message-json

### Patch Changes

- Updated dependencies
  - @xhs/modular-rpc@1.7.0

## 2.5.0

### Minor Changes

- fix core- externel webui

### Patch Changes

- Updated dependencies
  - @xhs/modular-rpc@1.6.0

## 2.4.0

### Minor Changes

- feat: webui
- bd657a8: feat webui

### Patch Changes

- Updated dependencies
- Updated dependencies [bd657a8]
  - @xhs/modular-rpc@1.5.0

## 2.3.0

### Minor Changes

- remove webui

### Patch Changes

- Updated dependencies
  - @xhs/modular-rpc@1.4.0

## 2.2.0

### Minor Changes

- feat-web0ui-bug

### Patch Changes

- Updated dependencies
  - @xhs/modular-rpc@1.3.0

## 2.1.0

### Minor Changes

- fix bug

### Patch Changes

- Updated dependencies
  - @xhs/modular-rpc@1.2.0

## 2.1.0

### Minor Changes

- fix runing

### Patch Changes

- Updated dependencies
  - @xhs/modular-rpc@1.1.0

## 2.0.1

### Patch Changes

- feat modular-webui@2.0.0

## 2.0.0

### Major Changes

- fix bug

## 1.0.0

### Major Changes

- 553a4b7: devtools project first release!!!

### Patch Changes

- Updated dependencies [553a4b7]
  - @xhs/modular-rpc@1.0.0

## 1.0.0-beta.0

### Major Changes

- devtools project first release!!!

### Patch Changes

- Updated dependencies
  - @xhs/modular-rpc@1.0.0-beta.0
