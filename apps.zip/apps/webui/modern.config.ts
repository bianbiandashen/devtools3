import { appTools, defineConfig } from '@modern-js/app-tools';
import { tailwindcssPlugin } from '@modern-js/plugin-tailwindcss';

// https://modernjs.dev/en/configure/app/usage
export default defineConfig({
  source: {
    mainEntryName: 'index',
  },
  html: {
    title: 'DevTools',
    disableHtmlFolder: true,
  },
  runtime: {
    router: true,
  },
  output: {
    svgDefaultExport: 'component',
    distPath: {
      html: '',
    },
    copy: [
      { from: 'src/tauri.js', to: 'tauri.js' } // 确保 tauri.js 文件被复制到输出目录
    ]
  },

  plugins: [appTools(), tailwindcssPlugin()],
});
