export enum TreeNodeType {
  RULE = 'RULE',
  DATA = 'DATA',
  GLOBAL_CONFIG = 'GLOBAL_CONFIG',
}

/** 支持 mock http 方法 */
export enum Method {
  GET = 'GET',
  POST = 'POST',
  PUT = 'PUT',
  DELETE = 'DELETE',
}

export const METHOD_OPTIONS = [
  { label: 'GET', value: 'GET' },
  { label: 'POST', value: 'POST' },
  { label: 'PUT', value: 'PUT' },
  { label: 'DELETE', value: 'DELETE' },
] as { label: Method; value: Method }[];
