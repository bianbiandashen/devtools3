import { useContext, useEffect, useMemo } from 'react';
import { Form, Select, Input, Space, Button, Typography, App } from 'antd';
// import { useHistory, useParams } from 'react-router-dom';
import {
  useParams,
  useNavigate,
  useSearchParams,
  useLocation,
} from '@modern-js/runtime/router';
import hotkeys from 'hotkeys-js';
import NormalContentLayout from '@/components/Layout/NormalContentLayout';
import { METHOD_OPTIONS } from '@/constants/mock';
import {
  createMockRule,
  findMatching,
  findMatchingTestURL,
  findMockRuleById,
  updateMockRule,
  existsMatching,
} from '@/request/mock';
import Context from '@/hooks/mockContext';
import { getSingleRecord } from '@/request/proxy';

interface MatchResult {
  match: boolean;
  matching: any;
  ruleId: any;
}

const EditRule = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { message, modal } = App.useApp();
  const { refreshMenu } = useContext(Context);
  const { ruleId } = useParams();
  const [searchParams] = useSearchParams({
    recordId: '',
  });
  // 编辑
  const isEdit = useMemo(() => ruleId !== 'new', [ruleId]);
  const recordId = useMemo(() => searchParams.get('recordId'), [searchParams]);
  // 一键从proxy创建mock标识
  const isOneStepFlag = useMemo(
    () => !isEdit && Boolean(recordId),
    [ruleId, searchParams],
  );

  const [form] = Form.useForm();

  useEffect(() => {
    hotkeys('ctrl+s, command+s', e => {
      e.preventDefault();
      onSubmit();
    });
    return () => {
      hotkeys.unbind('ctrl+s, command+s');
    };
  }, [location]);

  const initialValues = {
    enable: false,
    name: '',
    matching: '',
    method: 'GET',
    url: '',
    ruleId: 'new',
  };

  const loadProxyData = async () => {
    if (!recordId) {
      return;
    }
    const res = await getSingleRecord(Number(recordId));

    const data = res[0];
    const url = new URL(data?.url);
    form.setFieldsValue({
      enable: false,
      name: url.pathname,
      matching: `${url.origin}${url.pathname}`,
      method: data?.method,
      url: data?.url,
    });

    const matchResult = await findMatching({
      url: data?.url,
      method: data?.method,
    }).then(data => ({
      match: data.match,
      matching: data.matching,
      ruleId: data.ruleId,
    }));
    if (matchResult.match) {
      await modal.confirm({
        title: `是否直接新建数据`,
        width: 600,
        content: (
          <Typography.Text>
            发现有相同规则 matching:
            <Typography.Text type="secondary">
              {` ${matchResult.matching} `}
            </Typography.Text>
            ，是否直接新建数据?
          </Typography.Text>
        ),
        onOk() {
          navigate(
            `/mock/edit_data/${matchResult.ruleId}/new?recordId=${recordId}`,
          );
        },
        onCancel(close) {
          close?.();
        },
      });
    }
  };

  const loadData = () => {
    if (isOneStepFlag) {
      loadProxyData();
    } else if (isEdit && ruleId) {
      findMockRuleById(ruleId).then((data: any) => {
        if (data) {
          form.setFieldsValue({
            ...data,
            ruleId,
          });
        }
      });
    } else {
      form.setFieldsValue(initialValues);
    }
  };

  const handleMatch = async () => {
    const { url, matching } = form.getFieldsValue();
    if (!url) {
      message.error('请输入URL');
      return;
    }
    if (!matching) {
      message.error('请输入Matching');
      return;
    }
    try {
      const res = await findMatchingTestURL({ matching, url });
      if (res) {
        message.success('匹配成功');
      } else {
        message.error('匹配失败');
      }
    } catch (err: any) {
      message.error(`匹配失败: ${err?.message}`);
    }
  };

  useEffect(() => {
    loadData();
  }, [ruleId]);

  const rules = [{ required: true, message: '请输入' }];

  const createPreCheck = async (payload: any) => {
    // 一键创建已做前置校验，无需二次确认
    if (isOneStepFlag) {
      return true;
    }
    const isExists = await existsMatching({
      matching: form.getFieldValue('matching'),
      method: form.getFieldValue('method'),
    });

    let continueCreate = true;
    if (isExists?.exists) {
      continueCreate = await modal.confirm({
        width: 600,
        title: '是否继续创建',
        content: (
          <Typography.Text>
            已有相同规则matching:
            <Typography.Text type="secondary">
              {` ${payload.matching} `}
            </Typography.Text>
            ，是否继续创建？
          </Typography.Text>
        ),
      });
    }

    return continueCreate;
  };

  const onSave = async () => {
    await form.validateFields();
    const payload = {
      ...form.getFieldsValue(),
      ruleId,
    };
    let res = { success: false, ruleId: null };
    try {
      if (isEdit) {
        await updateMockRule(payload);
        message.success('保存成功');
      } else {
        const continueCreate = await createPreCheck(payload);
        // 确认
        if (continueCreate) {
          res = await createMockRule(payload);
          message.success('保存成功');
        }
      }
      refreshMenu();
    } catch (error) {
      message.error(`保存失败: ${error}`);
      res = { success: true, ruleId: null };
    }

    return res as { success: boolean; ruleId: string | null };
  };

  const onCancel = () => {
    navigate(-1);
  };
  const onSubmit = async () => {
    const res = await onSave();
    if (!isEdit && res?.ruleId) {
      navigate(`/mock/edit_rule/${res.ruleId}`);
    }
  };
  const nextStep = async () => {
    const res = await onSave();
    if (res?.ruleId) {
      navigate(`/mock/edit_data/${res.ruleId}/new?recordId=${recordId}`);
    }
  };
  const renderAction = () => {
    if (isOneStepFlag) {
      return (
        <Space>
          <Button className="w-32" type="primary" onClick={nextStep}>
            下一步
          </Button>
        </Space>
      );
    }
    return (
      <Space>
        <Button className="w-32" type="primary" onClick={onSubmit}>
          保存
        </Button>
        <Button className="w-32" onClick={onCancel}>
          取消
        </Button>
      </Space>
    );
  };

  return (
    <NormalContentLayout>
      <div className="max-w-5xl">
        <Form form={form} initialValues={initialValues} labelCol={{ span: 2 }}>
          <Form.Item name="name" label="名称" required rules={rules}>
            <Input className="w-96" placeholder="请输入名称" />
          </Form.Item>
          <Form.Item name="method" label="方法" required rules={rules}>
            <Select
              options={METHOD_OPTIONS}
              placeholder="请选择方法"
              showSearch
              className="w-96"
            />
          </Form.Item>
          <Form.Item
            name="matching"
            label="Matching"
            help={
              <Typography.Link
                target="_blank"
                href="https://github.com/pillarjs/path-to-regexp"
              >
                详细使用方法点击查看
              </Typography.Link>
            }
            required
            rules={rules}
          >
            <Input placeholder="支持url全匹配/正则" />
          </Form.Item>
          <Form.Item
            name="url"
            label="测试URL"
            help={
              <Typography.Link onClick={handleMatch}>
                测试URL是否可匹配
              </Typography.Link>
            }
          >
            <Input placeholder="测试URL是否可匹配|URL匹配案例" />
          </Form.Item>
          <Form.Item wrapperCol={{ offset: 8, span: 16 }}>
            {renderAction()}
          </Form.Item>
        </Form>
      </div>
    </NormalContentLayout>
  );
};

export default EditRule;
