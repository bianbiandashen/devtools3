import { useContext, useEffect, useMemo, useRef } from 'react';
import {
  useLocation,
  useNavigate,
  useParams,
  useSearchParams,
} from '@modern-js/runtime/router';
import { GetProps, Form, Input, Space, Button, message, Switch } from 'antd';
// eslint-disable-next-line import/no-named-as-default
import Editor, { loader } from '@monaco-editor/react';
import * as monaco from 'monaco-editor';
import hotkeys from 'hotkeys-js';
import NormalContentLayout from '@/components/Layout/NormalContentLayout';
import {
  createMockData,
  findMockDataById,
  updateMockData,
} from '@/request/mock';
import { getDecodedBody } from '@/request/proxy';
import Context from '@/hooks/mockContext';
interface MockDataResponse {
  dataId: string;
}
type MonacoEditorProps = GetProps<typeof Editor>;

loader.config({ monaco });

const Page = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { refreshMenu } = useContext(Context);
  const [messageApi, contextHolder] = message.useMessage();
  const { dataId, ruleId } = useParams<{ dataId: string; ruleId: string }>();
  const isEdit = useMemo(() => dataId !== 'new', [dataId]);
  const [searchParams] = useSearchParams({
    recordId: '',
  });
  const recordId = useMemo(() => searchParams.get('recordId'), [searchParams]);
  // 一键从proxy创建mock标识
  const isOneStepFlag = useMemo(
    () => !isEdit && Boolean(recordId),
    [isEdit, searchParams],
  );

  const editorRef = useRef<any>(null);
  const [form] = Form.useForm();

  useEffect(() => {
    hotkeys('ctrl+s, command+s', e => {
      e.preventDefault();
      onSubmit();
    });
    return () => {
      hotkeys.unbind('ctrl+s, command+s');
    };
  }, [location]);

  const initialValues = {
    key: '',
    dataId: '',
    enable: false,
    name: '',
    responseData: '',
  };

  const handleEditorDidMount: MonacoEditorProps['onMount'] = editor => {
    editorRef.current = editor;
  };

  const onSubmit = async () => {
    try {
      await form.validateFields();
    } catch (error: any) {
      form.scrollToField(error?.errorFields?.[0]?.name[0]);
      throw error;
    }
    try {
      if (isEdit && ruleId && dataId) {
        await updateMockData({
          ruleId,
          dataId,
          name: form.getFieldValue('name'),
          responseData: form.getFieldValue('responseData'),
        });
        messageApi.success('保存成功');
      } else {
        const res = (await createMockData({
          ...form.getFieldsValue(),
          ruleId,
        })) as MockDataResponse;
        messageApi.success('保存成功');

        if (res) {
          navigate(`/mock/edit_data/${ruleId}/${res?.dataId}`, {
            replace: true,
          });
        }
      }
      refreshMenu();
    } catch (error) {
      messageApi.error(`保存失败: ${error}`);
    }
  };

  const onCancel = () => {
    navigate(-1);
  };

  const loadProxyData = async () => {
    if (!recordId) {
      return;
    }
    const res = await getDecodedBody(Number(recordId));
    const str = JSON.stringify(JSON.parse(res.content), null, 2);
    form.setFieldsValue({
      key: '',
      enable: false,
      name: '',
      responseData: str,
    });
  };

  async function loadData() {
    form.setFieldsValue({
      ...initialValues,
      ruleId,
      dataId,
    });
    if (!ruleId || !dataId) {
      return;
    }
    if (isOneStepFlag) {
      loadProxyData();
      return;
    }
    if (ruleId === 'new' || dataId === 'new') {
      return;
    }
    const res = await findMockDataById(ruleId, dataId);
    form.setFieldsValue(res);
  }

  useEffect(() => {
    loadData();
  }, [dataId, ruleId]);

  const rules = [
    {
      required: true,
      message: '请输入',
    },
  ];

  return (
    <NormalContentLayout>
      {contextHolder}
      <Form
        layout="horizontal"
        form={form}
        initialValues={initialValues}
        labelCol={{ span: 2 }}
        scrollToFirstError={true}
        name="basic"
      >
        <Form.Item hidden name="enable" label="enable">
          <Switch />
        </Form.Item>
        <Form.Item required rules={rules} name="name" label="名称">
          <Input className="w-96" placeholder="请输入" />
        </Form.Item>
        <Form.Item
          required={isEdit}
          rules={isEdit ? rules : []}
          name="key"
          label="key"
          help={`唯一值，mock数据文件名，不填则随机生成`}
        >
          <Input className="w-96" placeholder="请输入key" disabled={isEdit} />
        </Form.Item>
        <Form.Item required rules={rules} name="responseData" label="返回值">
          <Editor
            height="70vh"
            defaultLanguage="json"
            theme="vs-dark"
            onMount={handleEditorDidMount}
          />
        </Form.Item>

        <Form.Item wrapperCol={{ offset: 8, span: 16 }}>
          <Space>
            <Button className="w-32" type="primary" onClick={onSubmit}>
              保存
            </Button>
            <Button className="w-32" onClick={onCancel}>
              取消
            </Button>
          </Space>
        </Form.Item>
      </Form>
    </NormalContentLayout>
  );
};

export default Page;
