import { Link, Outlet, useNavigate } from '@modern-js/runtime/router';
import hotkeys from 'hotkeys-js';
import IConfigJson from './layoutInterface';
import '@/styles/index.css';
import React, { useState, useEffect } from 'react';
import {
  Typography,
  Layout as AntLayout,
  Menu,
  ConfigProvider,
  Flex,
  App,
  Button,
  Dropdown,
} from 'antd';
import ExportIconWithTooltip from '@/components/ExportIconWithTooltip';
import { menuConfig } from '@/config/menu.config';
import '@/styles/layout.less';
import { invoke } from '@tauri-apps/api/tauri';
import { readPackageJson, savePackageConfig, selectFolder } from '@/utils';
// import insight from '@xhs/apm-insight';
import { uniqBy } from 'lodash-es';
import { FolderProvider, useFolderContext } from '@/hooks/useFolders';

const { Header, Content, Sider } = AntLayout;
const { Title } = Typography;

const loadScript = (src: any) => {
  return new Promise<void>((resolve, reject) => {
    const script = document.createElement('script');
    script.src = src;
    script.async = true;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error(`Failed to load script: ${src}`));
    document.head.appendChild(script);
  });
};

const initSight = async () => {
  try {
    !(window as any)?.insight &&
      (await loadScript(
        'https://fe-static.xhscdn.com/formula-static/@xhs/apm-insight@1.1.20/apm-insight.min.js',
      ));
    let configJson: IConfigJson;
    try {
      const configContent: string = await invoke('read_redpass_config_file');
      configJson = JSON.parse(configContent);
    } catch (error) {
      console.error('Failed to read config file:', error);
    }
    console.log('insight....', (window as any)?.insight);
    if ((window as any).insight) {
      (window as any).insight.init({
        jsError: {
          enableIgnoreDefaultError: true,
        },
        env: 'production',
        http: {
          enableResponseData: true,
        },
        getUserInfo: () => {
          return Promise.resolve({
            user: {
              type: 'User',
              value: {
                userId: configJson?.userInfo?.account_no as string,
              },
            },
          });
        },
        package: {
          name: 'modular-webui',
          version: '2.18.0',
        },
        performance: {
          getFrameObserve: () => true,
          SPA_LOAD: {
            type: 'LCP',
          },
        },
      });
    } else {
      console.error('insight is not available on the window object');
    }
  } catch (error) {
    console.error('Failed to initialize insight:', error);
  }
};

// 检查端口 7777 的函数
const checkPort7777AndNavigate = async (navigate: any, intervalId: number) => {
  try {
    const response = await invoke('check_port');
    console.log('check_port', response);
    if (response) {
      clearInterval(intervalId);
      navigate('/dev-proxy/list');
    }
  } catch (error) {
    console.error('Failed to check port 7777:', error);
  }
};

const Layout: React.FC = () => {
  const [collapsed, setCollapsed] = useState(true);
  const { folders, setFolders } = useFolderContext();
  const { folderName, folderList } = folders;
  const navigate = useNavigate();

  useEffect(() => {
    initSight();

    // 轮询调用 checkPort7777AndNavigate 每隔 5 秒
    const intervalId: any = setInterval(() => {
      checkPort7777AndNavigate(navigate, intervalId);
    }, 5000);

    // 清除定时器
    return () => clearInterval(intervalId);
  }, [navigate]);

  hotkeys.filter = function () {
    return true;
  };

  return (
    <ConfigProvider
      theme={{
        components: {
          Layout: {
            triggerBg: '#fff',
            triggerColor: '#002140',
            headerBg: '#fff',
          },
        },
      }}
    >
      <App>
        <AntLayout className="w-screen min-h-screen global-layout">
          <Header className="border-0 border-b border-gray-300 border-solid flex items-center">
            <Flex justify="space-between" align="center" className="w-full">
              <Link to="/">
                <Flex gap="12px" justify="center" align="center">
                  {/* <RedIcon /> */}
                  <Title level={5} className="m-0">
                    DevTools
                  </Title>
                </Flex>
              </Link>
              <span className="ml-4 flex items-center md:ml-6">
                <Dropdown.Button
                  menu={{
                    items: folderList,
                    onClick: () => {},
                  }}
                  className="ml-3"
                  overlayClassName="h-6"
                  placement="bottomRight"
                  icon={<ExportIconWithTooltip />}
                >
                  <span
                    onClick={async () => {
                      const path = await selectFolder();
                      if (path) {
                        const result = await readPackageJson(path);
                        setFolders((prevConfig: any) => {
                          return {
                            ...prevConfig,
                            folderList: uniqBy(
                              [...result, ...(folderList || [])],
                              'name',
                            ).map(item => ({
                              ...item,
                              label: item.name,
                              key: item.name,
                            })),
                          };
                        });
                        await savePackageConfig(
                          result && JSON.stringify(result),
                        );
                      }
                    }}
                  >
                    {folderName || '选择文件夹'}
                  </span>
                </Dropdown.Button>
              </span>
              {/* 添加按钮来触发创建和读取临时文件 */}
              {/* <Button type="primary" onClick={handleCreateAndReadTempFile}>
                Create and Read Temp File
              </Button> */}
            </Flex>
          </Header>
          <AntLayout>
            <Sider
              width={200}
              collapsible
              theme="light"
              collapsed={collapsed}
              collapsedWidth={80}
              onCollapse={value => setCollapsed(value)}
              className="border-0 border-r border-gray-300 border-solid"
            >
              <Menu
                mode="inline"
                defaultSelectedKeys={['1']}
                defaultOpenKeys={['sub1']}
                style={{ height: '100%', borderRight: 0 }}
                items={menuConfig}
                onClick={function (payload) {
                  navigate(payload.key);
                }}
              />
            </Sider>
            <AntLayout>
              <Content>
                <Outlet />
              </Content>
            </AntLayout>
          </AntLayout>
        </AntLayout>
      </App>
    </ConfigProvider>
  );
};

const Wrapper = () => (
  <FolderProvider>
    <Layout />
  </FolderProvider>
);

export default Wrapper;
