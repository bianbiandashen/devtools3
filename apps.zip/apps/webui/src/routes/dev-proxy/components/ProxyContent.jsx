import React, { useState } from 'react';
import { Card, Empty, Alert, Col, Typography, Spin, Button } from 'antd';
import { CSSTransition, TransitionGroup } from 'react-transition-group';
import './ProxyContent.css'; // 确保你有一个 CSS 文件来定义动画效果
import ConfigFileViewer from '../components/ConfigFileViewer';
const { Title, Text, Paragraph } = Typography;

const ProxyContent = ({
  selectedPath,
  proxyStarted,
  fileContent,
  configFilePath,
  selectedProject,
  tempCommandJson,
  onReboot, // 添加一个重启回调函数
  runnningItem,
}) => {
  return (
    <TransitionGroup>
      {selectedPath ? (
        proxyStarted ? (
          <CSSTransition key="content" timeout={300} classNames="fade">
            <Col>
              <>
                <Card title="Devtools-Proxy-Preview">
                  <Card
                    type="inner"
                    title="项目信息："
                    style={{ marginBottom: '20px' }}
                  >
                    <Paragraph>
                      <strong>项目名称：</strong>{' '}
                      {selectedProject ? selectedProject?.name : '暂无项目名称'}
                    </Paragraph>
                    <Paragraph>
                      <strong>项目描述：</strong>{' '}
                      {selectedProject
                        ? selectedProject.description
                        : '暂无项目描述'}
                    </Paragraph>
                    <Alert
                      message="Proxy启动成功"
                      type="success"
                      showIcon
                      style={{ marginTop: '20px' }}
                    />
                  </Card>
                  <Card type="inner">
                    <ConfigFileViewer
                      fileContent={fileContent}
                      configFilePath={configFilePath}
                      onReboot={onReboot} // 传递重启回调
                      tempCommandJson={tempCommandJson}
                      selectedProject={selectedProject}
                    />
                  </Card>
                </Card>
              </>
            </Col>
          </CSSTransition>
        ) : (
          <CSSTransition key="loading" timeout={300} classNames="fade">
            <Col
              style={{
                width: '100%',
                height: '100%',
                display: 'flex', // 使用Flex布局
                justifyContent: 'center', // 水平居中
                alignItems: 'center', // 垂直居中
                flexDirection: 'column', // 子元素垂直排列
              }}
            >
              <Spin
                size="large"
                tip={`正在为您开启 ${selectedProject?.name} 项目的代理...`} // 动态提示文本
                style={{ marginTop: '20px' }}
              />
            </Col>
          </CSSTransition>
        )
      ) : (
        <CSSTransition
          style={{ marginBottom: '20px', width: '100%', height: '100%' }}
          key="empty"
          timeout={300}
          classNames="fade"
        >
          <Card title="Devtools-Proxy-Preview">
            <Empty
              image={Empty.PRESENTED_IMAGE_SIMPLE}
              description="请选择相关项目启动Proxy"
              style={{ marginTop: '20px' }}
            />
          </Card>
        </CSSTransition>
      )}
    </TransitionGroup>
  );
};

export default ProxyContent;
