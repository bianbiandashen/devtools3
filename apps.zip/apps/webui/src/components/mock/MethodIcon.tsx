import { Typography } from 'antd';
import { Method } from '@/constants/mock';

const colorMap = {
  GET: '#52c41a',
  POST: '#1890ff',
  PUT: '#faad14',
  DELETE: '#f5222d',
} satisfies Record<Method, string>;

const mapText = {
  GET: 'GET',
  POST: 'POST',
  PUT: 'PUT',
  DELETE: 'DEL',
} satisfies Record<Method, string>;

const { Text } = Typography;

const MethodIcon = ({ method }: { method: Method }) => {
  return (
    <Text
      style={{
        color: colorMap[method],
        display: 'inline-block',
        width: 40,
      }}
      strong
    >
      {mapText[method] || method}
    </Text>
  );
};

export default MethodIcon;
