import { BulbOutlined, ApiOutlined, GlobalOutlined } from '@ant-design/icons';
import { MenuProps } from 'antd';
import React from 'react';

export const menuConfig: MenuProps['items'] = [
  {
    key: 'dev-proxy/list',
    icon: React.createElement(ApiOutlined),
    label: '代理（研发）',
  },
  {
    key: 'proxy/list',
    icon: React.createElement(GlobalOutlined),
    label: '接口监听',
  },
  {
    key: 'mock/home',
    icon: React.createElement(BulbOutlined),
    label: 'Mock',
  },
];
