interface DevToolProxy {
  proxy: {
    getRecords: (idStart: string | number, limit: number) => any; // Specify the correct return type instead of `any` if possible
    getSingleRecord: (id: number) => any;
    getSummaryList: () => any;
    getDecodedBody: (id: number) => any;
  };
}

const client = {
  get: (key: string): DevToolProxy => ({
    proxy: {
      getRecords: (idStart: string | number, limit: number) => { /* implementation here */ },
      getSingleRecord: (id: number) => { /* implementation here */ },
      getSummaryList: () => { /* implementation here */ },
      getDecodedBody: (id: number) => { /* implementation here */ },
    }
  })
}

const getDevTool = (): DevToolProxy => client.get('devtool');

function getLatestRecord() {
  return getDevTool().proxy.getRecords('', 1);
}

export async function getLatestId() {
  const latestRecord = await getLatestRecord();
  return latestRecord?.[0]?.id;
}

export function getRecords(idStart: number | null, limit: number) {
  return getDevTool().proxy.getRecords(idStart ?? '', limit);
}


export function getSingleRecord(id: number) {
  return getDevTool().proxy.getSingleRecord(id);
}

export function getSummaryList() {
  return getDevTool().proxy.getSummaryList();
}

export function getDecodedBody(id: number) {
  return getDevTool().proxy.getDecodedBody(id);
}
