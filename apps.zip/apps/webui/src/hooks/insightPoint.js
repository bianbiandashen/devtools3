import IConfigJson from '../routes/layoutInterface';
import { invoke } from '@tauri-apps/api/tauri';

export async function sendCustomPoint(measurementName, measurementData) {
  let configJson: IConfigJson;
  try {
    const configContent: string = await invoke('read_redpass_config_file');
    configJson = JSON.parse(configContent);
  } catch (error) {
    console.error('Failed to read config file:', error);
  }

  if (typeof measurementName !== 'string') {
    throw new Error('Measurement name must be a string');
  }

  window.insight.sendCustomPoint({
    measurement_name: measurementName,
    measurement_data: {
      measurement_data: measurementData,
      name: configJson?.userInfo?.name,
    },
  });
}
