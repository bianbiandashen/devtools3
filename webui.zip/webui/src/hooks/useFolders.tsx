import React, {
    createContext,
    useEffect,
    useMemo,
    useContext,
    useState,
} from 'react';

type IFolders = { folderName: string; folderList: any };

export type IFolderContext = {
    folders: IFolders;
    setFolders?: any;
};

const defaultValue: IFolderContext = {
    folders: { folderName: '', folderList: [] },
};

const FolderContext = createContext<IFolderContext>(defaultValue);

export const FolderProvider = ({ children }: any) => {
    const [folders, setFolders] = useState({
        folderName: '',
        folderList: [],
    });
    return (
        <FolderContext.Provider
            value={{
                folders,
                setFolders,
            }}
        >
            {children}
        </FolderContext.Provider>
    );
};

export const useFolderContext = (): IFolderContext => {
    const context = useContext(FolderContext);
    return context || defaultValue;
};
