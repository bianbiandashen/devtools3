// hooks/useLogin.ts
import { useEffect, useState } from 'react';
import { useNavigate } from '@modern-js/runtime/router';
import { getURLSearchParams } from '../utils';
import { getPorchLoginUrl, getCurrentUrl } from '../config/porch.config';
import { getUserInfo, loginSSO } from '../services/user';
import { invoke } from '@tauri-apps/api/tauri';

const useLogin = () => {
  const navigate = useNavigate();
  const [hasRedirected, setHasRedirected] = useState(false);
  const [isNavigating, setIsNavigating] = useState(false);

  const { ticket, redirect } = getURLSearchParams('ticket', 'redirect');
  const urlSearchParams = new URLSearchParams(window.location.search);


  console.log('urlSearchParams', urlSearchParams);
  console.log('urlSearchParams--ticket', ticket);
  console.log('urlSearchParams--redirect', redirect);

  useEffect(() => {
    console.log('ticket', ticket);
    console.log('getCurrentUrl()', getCurrentUrl());
    /** getCurrentUrl() = "http://127.0.0.1:8080/" */

    if (!ticket && !hasRedirected) {
      setHasRedirected(true); // 防止无限循环
    //   invoke('redirect', { url: getPorchLoginUrl({ service: getCurrentUrl() }) });
      return;
    }

    if (ticket && !isNavigating) {
      loginSSO(getCurrentUrl(), ticket)
        .then(() => {
          console.log('getPorchLoginUrl + success',  ticket);
          getUserInfo().then(()=>{})
        //   /** getPorchLoginUrl  = "http://login2.xiaohongshu.com/login?service=http%3A%2F%2F127.0.0.1%3A8080%2F"*/
        //   let href = getPorchLoginUrl({ service: getCurrentUrl() });
        //   if (href) {
        //     setIsNavigating(true); // 防止重复导航
        //     invoke('redirect', { url: href }).then(() => {
        //       setIsNavigating(false); // 重定向后更新状态
        //     });
        //   }
        })
        .catch((e) => {
            console.log('getPorchLoginUrl + success2 ',  e);
        //   const ROUTE_FORBIDDEN = '/hawk/403';
        //   try {
        //     const redirectPath = decodeURIComponent(new URLSearchParams(window.history.state.current.split('?')[1]).get('redirect') || '');
        //     invoke('redirect', { url: redirectPath !== '' ? `${ROUTE_FORBIDDEN}?fromPath=${redirectPath}` : ROUTE_FORBIDDEN }).then(() => {
        //       setIsNavigating(false); // 重定向后更新状态
        //     });
        //   } catch (error) {
        //     invoke('redirect', { url: ROUTE_FORBIDDEN }).then(() => {
        //       setIsNavigating(false); // 重定向后更新状态
        //     });
        //   }
        });
    }
  }, [ticket, redirect, hasRedirected, isNavigating, navigate]);
};

export default useLogin;
