import { createContext } from 'react';

export interface MockContextValue {
  /** 刷新配置规则 */
  refreshMenu: () => void;
}

export const defaultValue = () => ({
  refreshMenu: () => undefined,
});

export default createContext<MockContextValue>(defaultValue());
