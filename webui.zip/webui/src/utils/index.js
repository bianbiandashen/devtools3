// utils.js
import { open } from '@tauri-apps/api/dialog';
import { invoke } from '@tauri-apps/api/tauri';
import { readTextFile } from '@tauri-apps/api/fs';
import { notification } from 'antd';

export const selectFolder = async () => {
  try {
    const selected = await open({
      directory: true,
      multiple: false,
    });
    console.log(selected);
    return selected;
  } catch (error) {
    console.error('Failed to select folder:', error);
  }
};

export const readPackageJson = async path => {
  try {
    const packageJson = await invoke('read_package_json_files', { path });
    console.log('packageJson', packageJson);
    return packageJson;
  } catch (error) {
    console.error('Error reading package.json:', error);
  }
};

export const savePackageConfig = async packageConfig => {
  console.log('savePackageConfig', packageConfig);
  try {
    await invoke('save_path_config', { configs: packageConfig });
  } catch (error) {
    console.error('Failed to save path config:', error);
  }
};

export const readPackageConfigCache = async () => {
  try {
    const res = await invoke('read_path_config_cache');
    return res;
  } catch (error) {
    console.error('Failed to read path config cache:', error);
  }
};

/**
 * 生成一个 URL 对象
 * @param url 一个表示绝对或相对 URL 的 DOMString
 * @param base 一个表示基准 URL 的 DOMString
 * @param search URL 参数对象
 * @returns URL
 */
export function createURL(url?: string, base?: string | undefined, search?: Record<string, string>): URL {
  // eslint-disable-next-line no-underscore-dangle
  const _url = new URL(url || window.location.href, base)
  Object.entries(search || {}).forEach(([k, v]) => {
    _url.searchParams.set(k, v)
  })
  return _url
}

/**
 * 获取当前页面的 URL 参数
 * @param args 参数列表
 * @returns
 */
export function getURLSearchParams(...args: string[]) {
  const urlSearchParams = new URLSearchParams(window.location.search)
  return args.reduce((acc, cur) => {
    acc[cur] = urlSearchParams.get(cur)
    return acc
  }, {} as Record<string, string | null>)
}

export const clearPackageConfigCache = async () => {
  try {
    const res = await invoke('clear_path_config_cache');
    console.log('clearPackageConfigCache', res);
    return res;
  } catch (error) {
    console.error('Failed to read path config cache:', error);
  }
};

export const readConfigFile = async (
  path,
  setFileContent,
  setConfigFilePath,
) => {
  try {
    const configFile = `${path}/devtool.config.js`;
    console.log('readConfigFile', configFile);
    const content = await readTextFile(configFile);
    console.log('content', content);
    setFileContent(content);
    setConfigFilePath(configFile);
  } catch (error) {
    console.error('Error reading config file:', error);
  }
};

export const handleNotification = (msg, desc) => {
  notification.info({
    message: `${msg} `,
    description: `${desc}`,
  });
};

export const closePort7777 = async () => {
  try {
    const portToClose = 7777;
    const response = await invoke('close_established_connections_on_port', {
      port: portToClose,
    });
    console.log('close_established_connections_on_port', response);
    notification.success({
      message: '代理已关闭',
      description: response,
    });
  } catch (error) {
    console.error('Error:', error);
    notification.error({
      message: '关闭代理失败',
      description: `错误信息: ${error.message}`,
    });
  }
};

export const checkPort7777 = async () => {
  try {
    const response = await invoke('check_port');
    console.log('check_port', response);
    return response;
  } catch (error) {
    console.error('Failed to check port 7777:', error);
  }
};

export const checkSystemProxy = async setSystemStart => {
  try {
    const response = await invoke('is_proxy_enabled');
    if (response) {
      setSystemStart(true);
    } else {
      setSystemStart(false);
    }
  } catch (error) {
    console.error('Failed to check port 7777:', error);
    setProxyStart(false);
  }
};

export const loop = (callback, delay) => {
  const timer = setTimeout(async () => {
    clearTimeout(timer);
    await callback();
    loop(callback, delay);
  }, delay);
  return timer;
};
