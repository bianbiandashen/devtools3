import { http } from '@xhs/launcher'
import { EDITH_BASE_URL } from '../config/http.config'

const { get } = http

interface IPayload {
  businessCode?: string
  debug?: boolean
  porchUserId?: string
  snsUserId?: string
  sellerId?: string
  email?: string
  grayId?: string // 灰度投放 ID
}

export const getMenuTree = (payload?: IPayload): Promise<any> => get('GET_MENU_TREE', {
  params: {
    ...payload,
    systemCode: 'system_hawkeye',
  },
}, { baseURL: EDITH_BASE_URL })
