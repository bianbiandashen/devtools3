// services/user.ts
import axios from 'axios';
import { getPorchLogoutUrl } from '../config/porch.config';

const getEidthHost = () => {
  return `${window.location.protocol}//edith.xiaohongshu.com`
}

const instance = axios.create({
  baseURL: 'https://hawkeye.devops.xiaohongshu.com/', // 替换为你的 API 基础 URL
  timeout: 10000,
  headers: { 'Content-Type': 'application/json' },
});

export async function loginSSO(service: string, ticket: string) {
  console.log('loginSSO===>', service, ticket);
  return instance.post('api/hawk/ssoLogin', {
    service,
    ticket,
  });
}

export function getUserInfo() {
  return instance.get('api/hawk/userInfo');
}

export function logout() {
  return instance.get('api/hawk/logout').then(() => {
    window.location.href = getPorchLogoutUrl();
  });
}
