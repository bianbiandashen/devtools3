import { http } from '@xhs/launcher'

export interface IPageToolDisplayItem {
  menuId: number
  bannerId?: number
  wechatGroupMenuConfig: string
  bannerMenuConfig: string
  managerInfoList: {
    id: string
    name: string
    email: string
    avatar: string
  }[]
}

export function getPageToolList() {
  return http.post<{ infos: IPageToolDisplayItem[] }>('/api/edith/config/list', {})
}
