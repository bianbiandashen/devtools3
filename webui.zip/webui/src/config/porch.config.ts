import { createURL } from '../utils'
// import { getEnv } from '~/utils/env'

export const SSO_HOSTS = {
  dev: '//login2.sit.xiaohongshu.com',
  sit: '//login2.sit.xiaohongshu.com',
  beta: '//login2.beta.xiaohongshu.com',
  prod: '//login2.xiaohongshu.com',
} as const

// const env = getEnv()

const getSSOHost = () => {
  // if (env === 'dev') {
  //   // @ts-ignore LOGAN_PROXY_KEY  package.json 启动的时候设置
  //   if ((process.env.LOGAN_PROXY_KEY || '').indexOf('beta') > -1) {
  //     return SSO_HOSTS.beta
  //   }
  //   return SSO_HOSTS.sit
  // }
  // if (env === 'prod') {
  //   return SSO_HOSTS.prod
  // }

  return SSO_HOSTS.prod
}

const SSO_ORIGIN = `${window.location.protocol}${getSSOHost()}`

export function getCurrentUrl(): string {
  const currentURL = createURL()
  currentURL.searchParams.delete('ticket')
  return currentURL.href
}

/**
 * @param {object} URL 参数对象
 * @returns
 */
export function getPorchLoginUrl(search: Record<string, string>): string {
  return createURL('/login', SSO_ORIGIN, search).href
}

export function getPorchLogoutUrl(): string {
  return createURL('/logout', SSO_ORIGIN, { service: getCurrentUrl() }).href
}
