import { HttpConfig } from '@xhs/launcher'
// import { getLoganUrlByQuery } from '../utils'
// import { getEnv } from '../utils/env'

// const env = getEnv()

// @ts-ignore LOGAN_PROXY_KEY  package.json 启动的时候设置
// const development = getLoganUrlByQuery(process.env.LOGAN_PROXY_KEY || 'operating-sit')

const getEidthHost = () => {
  return `${window.location.protocol}//edith.xiaohongshu.com`
}

// todo 这个东西就很奇怪，只需要一个中心化的二次包装http就行，应该每个使用方都初始化baseUrl、transform
export const EDITH_BASE_URL = getEidthHost()

const httpConfig: HttpConfig = {
  BASE_URL: {
    development: EDITH_BASE_URL,
    // formula build -e test
    test: '',
    // formula build -e prerelease
    prerelease: '',
    // formula build
    production: '',
  },
  BASE_CONFIG: {
    defaults: {
      transform: false,
      timeout: 30000,
    },
    development: {
      withCredentials: true,
    },
    test: {
      withCredentials: true,
    },
  },
  API_LIST: {
    LOGIN_SSO: '/api/hawk/ssoLogin',
    LOGOUT: '/api/hawk/logout',
    USER_INFO: '/api/hawk/userInfo',

    // 获取菜单
    GET_MENU_TREE: '/api/fls/juliet/uno/get_menu_tree',
  },
}

export default httpConfig
