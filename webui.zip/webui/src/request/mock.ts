// import { Client4Web } from '@xhs/modular-rpc/dist/Client4Web';

// const client = new Client4Web({
//   host: 'ws://localhost:7777',
//   name: 'devtool-web',
//   methods: {},
//   keepAlive: 6e4,
// });

const client = {
    get: (key: string) => {
        return {
            'mock.findAllMockRules': () => ({}),
            'mock.findMockRuleById': (params: { ruleId: string }) => ({}),
            'mock.findMockDataById': (params: { ruleId: string, dataId: string }) => ({}),
            'mock.createMockRule': (payload: any) => ({}),
            'mock.updateMockRule': (payload: any) => ({}),
            'mock.updateMockRuleEnable': (payload: { ruleId: string; enable: boolean }) => ({}),
            'mock.deleteMockRule': (payload: { ruleId: string }) => ({}),
            'mock.createMockData': (payload: any) => ({}),
            'mock.updateMockData': (payload: {
                ruleId: string;
                dataId: string;
                name?: string;
                enable?: boolean;
                responseData?: any;
            }) => ({}),
            'mock.updateMockDataEnable': (payload: {
                ruleId: string;
                dataId: string;
                enable: boolean;
            }) => ({}),
            'mock.deleteMockData': (payload: { ruleId: string; dataId: string }) => ({}),
            'mock.findMatching': (payload: {
                url: string;
                method: string;
                ignoreEnable?: boolean;
            }) => ({}),
            'mock.findMatchingTestURL': (payload: {
                matching: string;
                url: string;
            }) => ({}),
            'mock.existsMatching': (payload: { matching: string; method: string }) => ({})
        };
    },
};

const getDevTool = () => client.get('devtool');

export function findAllMockRules() {
    return getDevTool()['mock.findAllMockRules']();
}

export function findMockRuleById(ruleId: string): Promise<any> {
    return Promise.resolve(getDevTool()['mock.findMockRuleById']({ ruleId }));
}

export function findMockDataById(ruleId: string, dataId: string): Promise<any> {
    return Promise.resolve(getDevTool()['mock.findMockDataById']({ ruleId, dataId }));
}
export function createMockRule(payload: any) {
    return getDevTool()['mock.createMockRule'](payload);
}

export function updateMockRule(payload: any) {
    return getDevTool()['mock.updateMockRule'](payload);
}


export function updateMockRuleEnable(payload: {
    ruleId: string;
    enable: boolean;
}) {
    return getDevTool()['mock.updateMockRuleEnable'](payload);
}

export function deleteMockRule(payload: { ruleId: string }) {
    return getDevTool()['mock.deleteMockRule'](payload);
}

export function createMockData(payload: any) {
    return getDevTool()['mock.createMockData'](payload);
}

export function updateMockData(payload: {
    ruleId: string;
    dataId: string;
    name?: string;
    enable?: boolean;
    responseData?: any;
}) {
    return getDevTool()['mock.updateMockData'](payload);
}

export function updateMockDataEnable(payload: {
    ruleId: string;
    dataId: string;
    enable: boolean;
}) {
    return getDevTool()['mock.updateMockDataEnable'](payload);
}

export function deleteMockData(payload: { ruleId: string; dataId: string }) {
    return getDevTool()['mock.deleteMockData'](payload);
}

export function findMatching(payload: {
    url: string;
    method: string;
    ignoreEnable?: boolean;
}) {
    return getDevTool()['mock.findMatching'](payload);
}

export function findMatchingTestURL(payload: {
    matching: string;
    url: string;
}) {
    return getDevTool()['mock.findMatchingTestURL'](payload);
}

export function existsMatching(payload: { matching: string; method: string }) {
    return getDevTool()['mock.existsMatching'](payload);
}
