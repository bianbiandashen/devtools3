// src/tauri.js

import { invoke } from '@tauri-apps/api/tauri';

// 在这里可以添加你的 Tauri API 调用逻辑
window.__TAURI__ = { invoke };
