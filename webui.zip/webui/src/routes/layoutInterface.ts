export type UserInfo = {
  account_no: string;
  deactivated: boolean;
  email: string;
  email_alias: string;
  mobile: string;
  name: string;
  name_alias: string;
  thumb_avatar: string;
} | null;

  interface CurrentEnv {
    type: string;
    url: string;
  }

  interface NextEnv {
    type: string;
    url: string;
  }

  interface RiskConfig {
    software: Record<string, unknown>;
    service: Record<string, unknown>;
  }

  interface RiskData {
    result: {
      software: {
        hit: boolean;
        response: any[];
        checked: boolean;
      };
      service: {
        hit: boolean;
        response: any[];
        checked: boolean;
      };
    };
    status: string;
    lastTime: string;
  }

  export default interface IConfigJson {
    VPNStatus: string;
    VPNStatusBeforeRestart: string;
    appStartTime: number;
    authToken: string;
    autoConnectVPN: boolean;
    connectRes: number;
    corpCode: string;
    currentAppVersion: string;
    currentEnv: CurrentEnv;
    disconnectMessage: string;
    equipmentBelong: string;
    fromUrl: boolean;
    intuneId: string;
    isBootStart: boolean;
    isFirstInstall: boolean;
    isOpenBeforeRestart: boolean;
    isOpenForPop: boolean;
    isScreenRecordPopOpen: boolean;
    jumpedVersion: string;
    lang: string;
    libraryDefaultDir: string;
    nextEnv: NextEnv;
    os: string;
    otpErrorCount: number;
    platform: string;
    porchBeakerSessionIdCookie: string;
    qywxConfig: Record<string, unknown>;
    qywxIframeStartTime: number;
    qywxStartTime: number;
    reauthPassTime: number;
    reconnectTime: number;
    redpassDid: string;
    riskConfig: RiskConfig;
    riskData: RiskData;
    riskHitTime: Record<string, unknown>;
    riskTotalTime: number;
    showUpgradeTag: boolean;
    strategyType: number;
    upgradeFilePath: string;
    upgradeVersion: string;
    userInfo: UserInfo;
    vpnErrorCount: number;
    vpnTextConfig: {
      time: number;
      text: string;
    };
    yunshuToken: string;
  }
