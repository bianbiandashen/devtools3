import React, { useEffect, useCallback } from 'react';
import { Card, Col, Row, Typography } from 'antd';
import { useNavigate } from '@modern-js/runtime/router';
import NormalContentLayout from '@/components/Layout/NormalContentLayout';
import { menuConfig } from '@/config/menu.config';
import { appWindow } from '@tauri-apps/api/window';
import { readTextFile, BaseDirectory } from '@tauri-apps/api/fs';
import { join, appDir } from '@tauri-apps/api/path';
import styles from './HomePage.module.css'; // 引入模块化CSS
import Login from '../components/Login';
import { sendCustomPoint } from '../hooks/insightPoint';

const { Title } = Typography;

const HomePage: React.FC = () => {
  const navigate = useNavigate();

  const handleCardClick = useCallback(
    itemKey => {
      sendCustomPoint('enter_devtools', `进入-${itemKey}`);
      navigate(itemKey);
    },
    [navigate],
  );

  return (
    <NormalContentLayout>
      <div className={styles.container}>
        <Title level={2} className={styles.title}>
          研发工作台插件市场
        </Title>
        <Row gutter={[16, 16]} justify="center">
          {menuConfig.map(item => (
            <Col key={item.key} xs={24} sm={12} md={8} lg={6}>
              <Card
                hoverable
                className={styles.card}
                onClick={() => handleCardClick(item.key)}
                cover={
                  <div className={styles.cardCover}>
                    <div className={styles.iconWrapper}>
                      {React.cloneElement(item.icon, {
                        style: { fontSize: '40px' },
                      })}
                    </div>
                  </div>
                }
                actions={[
                  <div className={styles.cardAction}>
                    <div className={styles.link}>{item.label}</div>
                  </div>,
                ]}
              >
                <Card.Meta
                  title={item.label}
                  description={`快速进入${item.label}`}
                />
              </Card>
            </Col>
          ))}
        </Row>
      </div>
    </NormalContentLayout>
  );
};

export default HomePage;
