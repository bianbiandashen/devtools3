import React, { useEffect } from 'react';
import { Input, Form, Space, Button, Select, message } from 'antd';
import NormalContentLayout from '@/components/Layout/NormalContentLayout';
import { METHOD_OPTIONS } from '@/constants/mock';
import { findMatching } from '@/request/mock';

const GeneratedPage = () => {
  const [form] = Form.useForm();
  const [messageApi, contextHolder] = message.useMessage();

  const onSubmit = async () => {
    console.log('onSubmit');

    const payload = {
      ...form.getFieldsValue(),
    };
    try {
      const res = await findMatching(payload);
      messageApi.info(res?.message);

      console.log(
        '%c __res__-22',
        'font-size:13px; background:#7df385; color:#c1ffc9;',
        res,
      );
    } catch (error) {
      console.log(
        '%c __error__-28',
        'font-size:13px; background:#7df385; color:#c1ffc9;',
        error,
      );
    }
  };

  const onCancel = () => {
    console.log('onCancel');
  };

  useEffect(() => {
    form.setFieldsValue({
      url: 'https://ark.xiaohongshu.com/edith/api/seller/fulfillment/over_due_report/zone_declare_change/v2',
      method: 'GET',
    });
  }, []);

  return (
    <NormalContentLayout>
      {contextHolder}
      <Form form={form} className="hidden">
        <Form.Item name="url" label="url">
          <Input />
        </Form.Item>
        <Form.Item name="method" label="method">
          <Select options={METHOD_OPTIONS} />
        </Form.Item>

        <Form.Item wrapperCol={{ offset: 8, span: 16 }}>
          <Space>
            <Button className="w-32" type="primary" onClick={onSubmit}>
              提交
            </Button>
            <Button className="w-32" onClick={onCancel}>
              取消
            </Button>
          </Space>
        </Form.Item>
      </Form>
      <div>
        <h1>Welcome to the Generated Page</h1>
        <p>This is a generated page.</p>
      </div>
    </NormalContentLayout>
  );
};

export default GeneratedPage;
