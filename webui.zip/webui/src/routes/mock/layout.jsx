/* eslint-disable max-lines */
import { useEffect, useMemo, useState } from 'react';
import {
  Button,
  Flex,
  Tree,
  Space,
  Typography,
  Switch,
  Dropdown,
  message,
  ConfigProvider,
} from 'antd';
import type { GetProps, TreeDataNode } from 'antd';
import { SwitchClickEventHandler } from 'antd/es/switch';
import { Outlet, useNavigate, useLocation } from '@modern-js/runtime/router';
import { Method, TreeNodeType } from '@/constants/mock';
import MethodIcon from '@/components/mock/MethodIcon';
import '@/styles/mock/mock_layout.less';
import {
  findAllMockRules,
  updateMockRuleEnable,
  deleteMockData,
  deleteMockRule,
  updateMockDataEnable,
} from '@/request/mock';
import Context from '@/hooks/mockContext';

type DirectoryTreeProps = GetProps<typeof Tree.DirectoryTree>;

interface CustomProps {
  type: TreeNodeType;
  enable?: boolean;
  ruleId?: string | number;
  dataId?: string | number;
  method?: Method;
  loading?: boolean;
  btns?: any[];
  key?: string;
}
interface CustomTreeDataNode extends TreeDataNode {
  customProps?: CustomProps;
  children?: CustomTreeDataNode[];
  title?: string;
  [key: string]: any;
}

const { DirectoryTree } = Tree;
const { Text } = Typography;

const App: React.FC = () => {
  const navigate = useNavigate();
  const localtion = useLocation();

  const [messageApi, contextHolder] = message.useMessage();
  const [treeData, setTreeData] = useState<CustomTreeDataNode[]>([]);
  const [selectedKeys, setSelectedKeys] = useState<string[]>([]);
  const [expandedKeys, setExpandedKeys] = useState<string[]>([]);
  const onSelect: DirectoryTreeProps['onSelect'] = (keys, info) => {
    // @ts-expect-error
    const { type, dataId, ruleId } = info.node.customProps as CustomProps;

    let navigatePath = '';
    if (type === TreeNodeType.RULE) {
      navigatePath = `/mock/edit_rule/${ruleId}`;
    } else if (type === TreeNodeType.DATA) {
      navigatePath = `/mock/edit_data/${ruleId}/${dataId}`;
    } else if (type === TreeNodeType.GLOBAL_CONFIG) {
      navigatePath = '/mock/home';
    }

    setSelectedKeys([navigatePath]);
    navigate(navigatePath);
  };

  const onExpand = (keys: React.Key[], info: { expanded: boolean }) => {
    if (info.expanded) {
      const set = new Set([...keys, ...expandedKeys]);
      // @ts-expect-error
      setExpandedKeys(Array.from(set));
    } else {
      // @ts-expect-error
      setExpandedKeys(keys);
    }
  };

  const [enableLoading, setEnableLoading] = useState<Record<string, boolean>>(
    {},
  );

  const handleToggleEnable =
    (node: CustomTreeDataNode): SwitchClickEventHandler =>
    async (checked, event) => {
      event.stopPropagation();
      event.preventDefault();
      setEnableLoading({ [String(node.key)]: true });

      try {
        if (node.customProps?.type === TreeNodeType.RULE) {
          await updateMockRuleEnable({
            ruleId: node.customProps?.ruleId as string,
            enable: checked,
          });
          node.customProps.enable = checked;
        } else if (node.customProps?.type === TreeNodeType.DATA) {
          await updateMockDataEnable({
            ruleId: node.customProps?.ruleId as string,
            dataId: node.customProps?.dataId as string,
            enable: checked,
          });
          node.customProps.enable = checked;
        }
        loadData();
      } finally {
        setEnableLoading({ [String(node.key)]: false });
      }
    };

  const titleRender: any = (node: CustomTreeDataNode) => {
    if (!node.customProps) {
      return [];
    }
    const { type, enable, method } = node.customProps;
    if (type && [TreeNodeType.RULE, TreeNodeType.DATA].includes(type)) {
      return (
        <Space className="mock-layout-title" size="small">
          {method && <MethodIcon method={method} />}
          <Switch
            size="small"
            checked={enable}
            loading={enableLoading[String(node.key)]}
            onClick={handleToggleEnable(node)}
          />
          <Text
            className="mock-layout-title-text w-36"
            title={node.customProps.key}
            ellipsis={{ tooltip: true }}
          >
            {node.title}
          </Text>
        </Space>
      );
    } else if (type === TreeNodeType.GLOBAL_CONFIG) {
      return <Text>{node.title}</Text>;
    }
    return <Text>{node.title}</Text>;
  };

  const [currentRightClickNode, setCurrentRightClickNode] =
    useState<CustomTreeDataNode | null>(null);
  const onRightClick: DirectoryTreeProps['onRightClick'] = info => {
    const node = info.node as CustomTreeDataNode;
    if (node.customProps?.type === TreeNodeType.GLOBAL_CONFIG) {
      setCurrentRightClickNode(null);
      return;
    }
    setCurrentRightClickNode(node);
  };

  const menuRightMenu = useMemo(() => {
    const { ruleId, dataId, type } = currentRightClickNode?.customProps || {};
    const menubase = {
      [TreeNodeType.RULE]: [
        {
          label: '新建数据',
          key: '/mock/edit_data/{ruleId}/new',
          type: TreeNodeType.RULE,
          onClick() {
            navigate(`/mock/edit_data/${ruleId}/new`);
          },
        },
        {
          label: '删除规则',
          key: 'delete_rule',
          type: TreeNodeType.RULE,
          async onClick() {
            await deleteMockRule({ ruleId: ruleId as string });
            messageApi.success('删除成功');
            loadData();
            navigate('/mock/home');
          },
        },
      ],
      [TreeNodeType.DATA]: [
        {
          label: '删除数据',
          key: 'delete_data',
          type: TreeNodeType.DATA,
          async onClick() {
            await deleteMockData({
              ruleId: ruleId as string,
              dataId: dataId as string,
            });
            messageApi.success('删除成功');
            loadData();
            navigate('/mock/home');
          },
        },
      ],
      [TreeNodeType.GLOBAL_CONFIG]: [],
    };
    if (!type) {
      return [];
    }

    return menubase[type] || [];
  }, [currentRightClickNode]);

  const setDefaultSelectedKeys = () => {
    // 设置当前路由对应的菜单
    setSelectedKeys([localtion.pathname]);
    for (const data of treeData) {
      if (data.children) {
        const find = data.children.find(child => {
          if (child.key === localtion.pathname) {
            return true;
          }
          return false;
        });
        if (find) {
          onExpand(Array.from(new Set([data.key as string, ...expandedKeys])), {
            expanded: true,
          });
          break;
        }
      }
    }
  };

  useEffect(() => {
    setDefaultSelectedKeys();
  }, [localtion.pathname, treeData]);

  const loadData = async () => {
    const res = await findAllMockRules();
    const base = [
      {
        title: '全局配置',
        key: '/mock/home',
        isLeaf: true,
        customProps: {
          type: TreeNodeType.GLOBAL_CONFIG,
        },
      },
    ];
    const data = res.map((item: any) => {
      return {
        title: item.name,
        key: `/mock/edit_rule/${item.ruleId}`,
        customProps: {
          enable: item.enable,
          type: TreeNodeType.RULE,
          ruleId: item.ruleId,
          method: item.method as Method,
        },
        children: (item?.dataList || []).map((dataItem: any) => {
          return {
            title: dataItem.name,
            key: `/mock/edit_data/${item.ruleId}/${dataItem.dataId}`,
            isLeaf: true,
            customProps: {
              ...dataItem,
              ruleId: item.ruleId,
              type: TreeNodeType.DATA,
            },
          };
        }),
      };
    });

    const composeData: CustomTreeDataNode[] = [...base, ...data];
    setTreeData(composeData);
  };

  useEffect(() => {
    loadData();
  }, []);

  return (
    <Context.Provider value={{ refreshMenu: loadData }}>
      <ConfigProvider
        theme={{
          components: {
            Tree: {
              directoryNodeSelectedBg: 'rgb(22, 119, 255, .4)',
            },
          },
        }}
      >
        <Flex flex={'100px 1'} className="h-full mock-layout">
          {contextHolder}
          <Flex className="bg-white p-2" vertical={true} gap={12}>
            <Button
              type="primary"
              onClick={() => navigate('/mock/edit_rule/new')}
            >
              新建规则
            </Button>
            {/* <Button
              type="primary"
              onClick={() => {
                loadData();
              }}
            >
              刷新
            </Button> */}
            <Dropdown menu={{ items: menuRightMenu }} trigger={['contextMenu']}>
              <DirectoryTree
                defaultExpandAll
                onSelect={onSelect}
                treeData={treeData}
                className="h-full"
                style={{ minWidth: 200 }}
                expandAction={'doubleClick'}
                titleRender={titleRender}
                onRightClick={onRightClick}
                showIcon={false}
                blockNode
                selectedKeys={selectedKeys}
                expandedKeys={expandedKeys}
                onExpand={onExpand}
              />
            </Dropdown>
          </Flex>
          <div className="flex-1">
            <Outlet />
          </div>
        </Flex>
      </ConfigProvider>
    </Context.Provider>
  );
};

export default App;
