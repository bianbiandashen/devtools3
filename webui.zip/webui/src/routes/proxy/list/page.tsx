import React, { useState, useEffect } from 'react';
import {
  Divider,
  Button,
  Space,
  Input,
  Table,
  Dropdown,
  MenuProps,
} from 'antd';
import DetailDrawer from './components/DetailDrawer';
import NormalContentLayout from '@/components/Layout/NormalContentLayout';
import { getLatestId, getRecords, getDecodedBody } from '@/request/proxy';

const { Search } = Input;

const ListPage: React.FC = () => {
  const [visible, setVisible] = useState(false);
  const [pause, setPause] = useState(false);
  const [filterValue, setFilterValue] = useState('');
  const [selectedRowData, setSelectedRowData] = useState<{
    request: Record<string, any>;
    response: Record<string, any>;
  }>({
    request: {},
    response: {},
  });
  const [dataSource, setDataSource] = useState<Record<string, any>[]>([]);

  const fetchData = async () => {
    const startId: number = dataSource?.[0]?.key || 0;
    const latestId = await getLatestId();

    let res = [];
    if (startId === 0) {
      res = await getRecords(null, 50);
    } else if (startId < latestId) {
      res = await getRecords(startId + 1, latestId - startId);
    }

    if (res?.length > 0) {
      const n = (res || [])
        .reverse()
        ?.map((i: { id: any }) => ({ ...i, key: i.id }));
      setDataSource([...n, ...(dataSource || [])]);
    }
  };

  useEffect(() => {
    const id = setInterval(() => {
      if (!pause) {
        fetchData();
      }
    }, 1000);
    return () => clearInterval(id);
  }, []);

  const setDetailData = async (record: any) => {
    const bodyData = await getDecodedBody(record.key);
    setSelectedRowData({
      request: record || {},
      response: bodyData,
    });
  };

  const showDrawer = async (record: any) => {
    setDetailData(record);
    setVisible(true);
  };

  const onClose = () => {
    setVisible(false);
  };

  const onPause = () => {
    setPause(!pause);
  };

  const onClear = () => {
    setDataSource([]);
  };

  const useFilter = () => {
    if (!filterValue) {
      return dataSource;
    }
    return dataSource.filter((i: any) => {
      return (
        i.url.includes(filterValue) ||
        i.method.includes(filterValue) ||
        i.statusCode.toString().includes(filterValue)
      );
    });
  };

  const columns = [
    {
      title: 'URL',
      dataIndex: 'url',
      render: (url: string) => {
        const menuItems: MenuProps['items'] = [
          {
            label: '存储为mock数据',
            key: 'saveAsMock',
          },
        ];
        const onClick: MenuProps['onClick'] = ({ key, domEvent }) => {
          domEvent.preventDefault();
          domEvent.stopPropagation();
          if (key === 'saveAsMock') {
            console.log('save as mock');
            window.open(
              `/mock/edit_rule/new?recordId=${selectedRowData.request.id}`,
              '_blank',
            );
          }
        };
        const onOpenChange = (open: boolean) => {
          setPause(open);
        };
        return (
          <Dropdown
            menu={{ items: menuItems, onClick }}
            onOpenChange={onOpenChange}
            arrow={true}
            trigger={['contextMenu']}
          >
            <div style={{ wordBreak: 'break-all' }}>{url}</div>
          </Dropdown>
        );
      },
    },
    {
      title: 'Status',
      dataIndex: 'statusCode',
    },
    {
      title: 'Method',
      dataIndex: 'method',
    },
    {
      title: 'Size',
      dataIndex: 'size',
    },
    {
      title: 'Duration',
      dataIndex: 'duration',
      render: (duration: number) => <div>{`${duration} ms`}</div>,
    },
  ];

  return (
    <NormalContentLayout>
      <Space>
        <Button onClick={onPause}>{pause ? '恢复' : '暂停'}</Button>
        <Button onClick={onClear}>清空</Button>
        <Divider type="vertical" />
        <Search
          placeholder="Filter"
          onSearch={value => setFilterValue(value)}
          style={{ width: 300 }}
        />
      </Space>
      <Table
        style={{ marginTop: 20 }}
        columns={columns}
        dataSource={useFilter()}
        onRow={record => {
          return {
            onClick: () => showDrawer(record),
            onContextMenu: event => {
              event.preventDefault();
              setDetailData(record);
            },
          };
        }}
      />
      <DetailDrawer
        visible={visible}
        onClose={onClose}
        data={selectedRowData}
      />
    </NormalContentLayout>
  );
};

export default ListPage;
