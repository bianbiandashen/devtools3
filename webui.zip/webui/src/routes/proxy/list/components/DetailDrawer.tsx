import React from 'react';
import { Drawer, Tabs, Collapse } from 'antd';
import './index.css';

const { TabPane } = Tabs;
const { Panel } = Collapse;

type IProps = {
  visible: boolean;
  onClose: () => void;
  data: {
    request: Record<string, any>;
    response: Record<string, any>;
  };
};
const DetailDrawer: React.FC<IProps> = props => {
  const {
    visible,
    onClose,
    data: { request, response },
  } = props;

  const { content: responseContent, ...responseHeaders } = response;

  const renderObject = (obj: Record<string, any>) => {
    return Object.keys(obj || {})?.length
      ? Object.keys(obj).map(k => (
          <p key={k}>
            {k}: {obj[k]}
          </p>
        ))
      : null;
  };

  return (
    <Drawer
      title="Request and Response Details"
      width={720}
      onClose={onClose}
      visible={visible}
      bodyStyle={{ paddingBottom: 80 }}
      className="detail-drawer"
    >
      <Tabs defaultActiveKey="Response">
        <TabPane tab="Request" key="Request">
          {/* <p>{JSON.stringify(request)}</p> */}
          <Collapse defaultActiveKey={['General', 'Headers', 'Payload']}>
            <Panel header="General" key="General">
              <p>Request Url: {request.url}</p>
              <p>Request Method: {request.method}</p>
              <p>Request Protocol: {request.protocol}</p>
            </Panel>
            <Panel header="Headers" key="Headers">
              {renderObject(request?.reqHeader)}
            </Panel>
            {request.reqBody && (
              <Panel header="Payload" key="Payload">
                <p>{request.reqBody}</p>
              </Panel>
            )}
          </Collapse>
        </TabPane>
        <TabPane tab="Response" key="Response">
          {/* <p>{JSON.stringify(response)}</p> */}
          <Collapse defaultActiveKey={['Headers', 'Body']}>
            <Panel header="Headers" key="Headers">
              {renderObject(responseHeaders)}
            </Panel>
            <Panel header="Body" key="Body">
              <p>{responseContent}</p>
            </Panel>
          </Collapse>
        </TabPane>
      </Tabs>
    </Drawer>
  );
};

export default DetailDrawer;
