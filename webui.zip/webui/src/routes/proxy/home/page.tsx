import React from 'react';
import { Typography } from 'antd';
import NormalContentLayout from '@/components/Layout/NormalContentLayout';

const { Title } = Typography;

const HomePage: React.FC = () => {
  return (
    <NormalContentLayout>
      <div className="flex justify-center items-center h-screen">
        <Title>Welcome to the Proxy Home Page</Title>
      </div>
    </NormalContentLayout>
  );
};

export default HomePage;
