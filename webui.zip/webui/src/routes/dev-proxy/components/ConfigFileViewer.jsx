import React, { useState } from 'react';
import { Typography, Button } from 'antd';
import { Controlled as CodeMirror } from 'react-codemirror2';
import 'codemirror/lib/codemirror.css';
import 'codemirror/mode/javascript/javascript';
import 'codemirror/theme/material.css';

const { Title } = Typography;

const ConfigFileViewer = ({
  fileContent,
  configFilePath,
  onReboot,
  selectedProject,
  tempCommandJson,
}) => {
  const [content, setContent] = useState(fileContent);

  return (
    <div
      style={{
        marginTop: '12px',
        border: '1px solid #ddd',
        borderRadius: '4px',
        padding: '12px',
        width: '600px',
      }}
    >
      <Title level={5} style={{ marginBottom: '8px' }}>
        Proxy config:
      </Title>
      <p>如需同时开发更多项目，可以修改下方配置文件并点击重启。</p>
      <CodeMirror
        value={tempCommandJson || content}
        options={{
          mode: 'javascript',
          theme: 'material',
          lineNumbers: true,
        }}
        onBeforeChange={(editor, data, value) => {
          setContent(value);
        }}
      />
      <Button
        type="primary"
        style={{ marginTop: '12px', float: 'right' }}
        onClick={
          () => {
            onReboot(selectedProject, content);
          } // 点击按钮触发重启回调
        }
      >
        重启
      </Button>
    </div>
  );
};

export default ConfigFileViewer;
