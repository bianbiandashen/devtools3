import React, { useEffect, useState, useMemo } from 'react';
import { List, Button, Typography, Space, Empty, Tooltip, Popover } from 'antd';
import {
  CaretRightOutlined,
  StopOutlined,
  CodeOutlined,
  FileTextOutlined,
  ExclamationCircleFilled,
  WarningFilled,
} from '@ant-design/icons';
import { CSSTransition, TransitionGroup } from 'react-transition-group';
import { invoke } from '@tauri-apps/api';
import './DirectoryList.css';

const { Title, Text, Link } = Typography;

const DirectoryList = ({
  directories,
  loading,
  handleRunCommand,
  closeWebSocket,
  openInVSCode,
  setSelectedPath,
  onSelect,
  proxyStarted,
}) => {
  const [directoryStates, setDirectoryStates] = useState({});

  useEffect(() => {
    // Check for the existence of devtool.config.js for each directory
    directories?.forEach(async directory => {
      const exists = await invoke('check_devtool_config_exists', {
        path: directory.path,
      });
      setDirectoryStates(prevState => ({
        ...prevState,
        [directory.path]: exists,
      }));
    });
  }, [directories]);

  const sortedDirectories = useMemo(() => {
    return directories?.sort((a, b) => (directoryStates[a.path] ? -1 : 1));
  }, [directories, directoryStates]);

  const renderListItem = item => {
    const showNotice = !directoryStates[item.path];
    const content = (
      <List.Item
        onClick={() => onSelect(item)}
        style={{
          display: 'flex',
          alignItems: 'center',
          width: '100%',
          position: 'relative',
          pointerEvents: 'auto', // Ensure pointer events are enabled
        }}
      >
        <List.Item.Meta
          avatar={
            <FileTextOutlined
              style={{
                fontSize: '24px',
                color: '#1890ff',
              }}
            />
          }
          title={
            <span style={{ display: 'flex' }}>
              <Title
                level={4}
                style={{
                  margin: 0,
                  fontSize: '16px',
                }}
              >
                {item.name}
              </Title>
              {showNotice ? (
                <ExclamationCircleFilled
                  className="ml-1"
                  style={{ color: '#ff4d4f' }}
                />
              ) : null}
            </span>
          }
          description={
            <Text style={{ fontSize: '14px' }} type="secondary">
              {item.description || '暂无描述'}
            </Text>
          }
        />
        <Space>
          <Button
            type={proxyStarted ? 'danger' : 'primary'}
            disabled={!directoryStates[item.path]}
            shape="circle"
            icon={
              proxyStarted ? (
                <StopOutlined
                  style={{
                    color: '#ffffff',
                  }}
                />
              ) : (
                <CaretRightOutlined
                  style={{
                    color: '#ffffff',
                  }}
                />
              )
            }
            size="large"
            onClick={() => {
              if (proxyStarted) {
                closeWebSocket();
              } else {
                handleRunCommand(item);
              }
            }}
            style={{
              transition: 'transform 0.3s',
              outline: 'none',
              backgroundColor: proxyStarted ? '#ff4d4f' : '#52c41a',
              borderColor: proxyStarted ? '#ff4d4f' : '#52c41a',
            }}
            onMouseEnter={e => (e.currentTarget.style.transform = 'scale(1.1)')}
            onMouseLeave={e => (e.currentTarget.style.transform = 'scale(1)')}
            onFocus={e => (e.currentTarget.style.transform = 'scale(1.1)')}
            onBlur={e => (e.currentTarget.style.transform = 'scale(1)')}
          />
          <Button
            type="default"
            shape="circle"
            icon={<CodeOutlined />}
            size="large"
            onClick={() => openInVSCode(item.path)}
            style={{
              transition: 'transform 0.3s',
              outline: 'none',
            }}
            onMouseEnter={e => (e.currentTarget.style.transform = 'scale(1.1)')}
            onMouseLeave={e => (e.currentTarget.style.transform = 'scale(1)')}
            onFocus={e => (e.currentTarget.style.transform = 'scale(1.1)')}
            onBlur={e => (e.currentTarget.style.transform = 'scale(1)')}
          />
        </Space>
      </List.Item>
    );
    if (showNotice) {
      return (
        <Popover
          title={
            <Text type="danger">
              <WarningFilled className="mr-1" />
              检测到异常
            </Text>
          }
          content={
            <>
              <Text type="danger">
                该仓库下暂无.devtool.config.js, 请
                <Link
                  onClick={() => openInVSCode(item.path)}
                  style={{
                    marginLeft: '4px',
                    cursor: 'pointer',
                  }}
                >
                  前往
                </Link>
                仓库下创建文件
              </Text>
            </>
          }
        >
          {content}
        </Popover>
      );
    }
    return content;
  };

  return (
    <div className="outer-container">
      <div className="directory-list-container">
        <TransitionGroup>
          <List
            size="large"
            dataSource={sortedDirectories}
            renderItem={item => (
              <CSSTransition key={item.path} timeout={300} classNames="fade">
                {renderListItem(item)}
              </CSSTransition>
            )}
            locale={{
              emptyText: (
                <Empty
                  image={Empty.PRESENTED_IMAGE_SIMPLE}
                  description={<span>请点击上方导入文件</span>}
                />
              ),
            }}
          />
        </TransitionGroup>
      </div>
    </div>
  );
};

export default DirectoryList;
