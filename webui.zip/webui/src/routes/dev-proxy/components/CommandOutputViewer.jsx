import React from 'react';
import { Typography } from 'antd';
import { Controlled as CodeMirror } from 'react-codemirror2';
import 'codemirror/lib/codemirror.css';
import 'codemirror/mode/shell/shell';
import 'codemirror/theme/material.css';

const { Title } = Typography;

const CommandOutputViewer = ({ commandOutput }) => {
  return (
    <div
      style={{
        marginTop: '12px',
        border: '1px solid #ddd',
        borderRadius: '4px',
        padding: '12px',
        width: '600px',
      }}
    >
      <Title level={5} style={{ marginBottom: '8px' }}>
        命令执行结果:
      </Title>
      <CodeMirror
        value={commandOutput}
        options={{
          mode: 'shell',
          theme: 'material',
          lineNumbers: true,
          readOnly: true,
        }}
        onBeforeChange={(editor, data, value) => {
          // 仅仅显示内容，禁止编辑
        }}
      />
    </div>
  );
};

export default CommandOutputViewer;
