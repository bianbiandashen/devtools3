import React, { useEffect, useState } from 'react';
import {
  Card,
  Empty,
  Alert,
  Col,
  Typography,
  Spin,
  Button,
  Tag,
  List,
  Collapse,
  Popconfirm,
  Space,
  notification,
} from 'antd';
import { CSSTransition, TransitionGroup } from 'react-transition-group';
import './ProxyContent.css'; // 确保你有一个 CSS 文件来定义动画效果
import ConfigFileViewer from '../components/ConfigFileViewer';
import {
  PauseCircleFilled,
  PlayCircleFilled,
  FolderOpenFilled,
  CaretRightOutlined,
  StopOutlined,
} from '@ant-design/icons';
import { invoke } from '@tauri-apps/api/tauri';
import { listen } from '@tauri-apps/api/event';

const { Title, Text, Paragraph } = Typography;

const ProxyContent = ({
  selectedPath,
  proxyStarted,
  fileContent,
  configFilePath,
  selectedProject,
  tempCommandJson,
  onReboot, // 添加一个重启回调函数
  runnningItem,
  openInVSCode,
  closeWebSocket,
  handleRunCommand,
  tab,
}) => {
  console.log('🚀 ~ selectedProject =======>', tab, selectedProject);
  const { name, version, workspaces, scripts, path } = selectedProject || {};
  // TODO: 三个State合并成一个
  const [runningKeys, setRunningKeys] = useState({});
  const [runningLogs, setRunningLogs] = useState({});
  const [runningPids, setRunningPids] = useState({});

  useEffect(() => {
    const listener = listen('project-script-run-output', event => {
      const key = event.payload.match(/\[(.*?)\]/)[1];
      if (event.payload.includes('current pid is')) {
        const pid = event.payload.match(/##(.*?)##/)[1];
        setRunningPids(prev => {
          const newObj = JSON.parse(JSON.stringify(prev));
          if (!newObj[key]) {
            newObj[key] = '';
          }
          newObj[key] = Number(pid);
          return newObj;
        });
        return;
      }
      setRunningLogs(prev => {
        const newObj = JSON.parse(JSON.stringify(prev));
        if (!newObj[key]) {
          newObj[key] = '';
        }
        newObj[key] = newObj[key] + '\n' + event.payload;
        return newObj;
      });
    });
    return () => {
      listener.then(fn => fn());
    };
  }, []);

  const getTagItem = (label, color = 'green') => (
    <span className="card-title-tag">
      <Tag color={color}>{label}</Tag>
    </span>
  );

  const handleTagList = () => {
    const tagList = [];
    if (version) {
      tagList.push(getTagItem(version));
    }
    if (workspaces) {
      tagList.push(getTagItem('Monorepo', '#2db7f5'));
    }
    return tagList;
  };

  const renderTitle = () => {
    const isActive = Object.keys(scripts || {}).some(item => {
      return runningKeys[`${name}-${item}`] === 1;
    });
    return (
      <div className="card-title-wrapper">
        <span className="card-title-header-left">
          <span
            className="card-title-name"
            onClick={() => {
              if (path) {
                openInVSCode(path);
              }
            }}
          >
            <FolderOpenFilled
              style={{ color: '#4096ff', fontSize: 18, marginRight: 8 }}
            />
            {name}
          </span>
          {handleTagList()}
        </span>
        <span className="card-title-header-right">
          {isActive && (
            <Popconfirm
              title={`请确认要全部停止吗？`}
              onConfirm={() => {
                closeWebSocket();
                setRunningKeys(prev => {
                  const newObj = JSON.parse(JSON.stringify(prev));
                  Object.keys(scripts || {}).forEach(key => {
                    newObj[`${name}-${key}`] = 2;
                  });
                  return newObj;
                });
              }}
              onCancel={() => {}}
              okText="确认"
              cancelText="取消"
            >
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <PauseCircleFilled
                  style={{
                    color: '#ff4d4f',
                    fontSize: 20,
                    marginRight: 8,
                  }}
                />
                全部停止
              </div>
            </Popconfirm>
          )}
        </span>
      </div>
    );
  };

  const renderProject = () => {
    const renderExtra = key => {
      const isRunning = runningKeys[`${name}-${key}`] === 1;
      return (
        <span
          onClick={e => {
            e.stopPropagation();
            e.preventDefault();
          }}
        >
          <Popconfirm
            title={`请确认要${isRunning ? '停止' : '启动'}吗？`}
            description="命令详细信息请稍候打开面板查看"
            onConfirm={async () => {
              setRunningKeys(prev => {
                const newObj = JSON.parse(JSON.stringify(prev));
                if (!newObj[`${name}-${key}`]) {
                  newObj[`${name}-${key}`] = 1;
                }
                // 1代表启动，2代表暂停
                newObj[`${name}-${key}`] = isRunning ? 2 : 1;
                return newObj;
              });
              if (isRunning) {
                setRunningLogs(prev => {
                  const newObj = JSON.parse(JSON.stringify(prev));
                  delete newObj[`${name}-${key}`];
                  return newObj;
                });
                try {
                  setRunningLogs({});
                  closeWebSocket();
                  notification.success({
                    message: '已停止',
                    description: res,
                  });
                } catch (error) {
                  notification.error({
                    message: 'Error executing command',
                    description: `Error: ${error}`,
                  });
                }
              } else {
                try {
                  invoke(
                    key === 'devtools'
                      ? 'exec_spawn_command_by_port'
                      : 'run_devtool',
                    {
                      key: `${name}-${key}`,
                      path,
                      command: `run ${key}`,
                      port: 'project-script-run-output',
                    },
                  );
                } catch (error) {
                  notification.error({
                    message: 'Error executing command',
                    description: `Error: ${error}`,
                  });
                }
              }
            }}
            onCancel={() => {}}
            okText="确认"
            cancelText="取消"
          >
            {isRunning ? (
              <PauseCircleFilled
                style={{
                  color: '#ff4d4f',
                  fontSize: 20,
                }}
              />
            ) : (
              <PlayCircleFilled
                style={{
                  color: '#52c41a',
                  fontSize: 20,
                }}
              />
            )}
          </Popconfirm>
        </span>
      );
    };

    const items = Object.keys(scripts || {}).map((key, index) => {
      return {
        key,
        label: (
          <Space>
            <Text>
              {' '}
              {key === 'devtools'
                ? '启动代理'
                : key === 'dev'
                ? '启动项目'
                : key}
            </Text>
            <Text type="secondary">{scripts[key]}</Text>
          </Space>
        ),
        children: (
          <Card
            style={{
              backgroundColor: '#1e1e1e',
              color: '#d4d4d4',
              fontFamily: 'monospace',
              borderRadius: '8px',
              boxShadow: '0 0 15px rgba(0, 0, 0, 0.2)',
            }}
          >
            <pre
              style={{
                whiteSpace: 'pre-wrap',
                wordWrap: 'break-word',
              }}
            >
              {runningLogs[`${name}-${key}`]}
            </pre>
          </Card>
        ),
        extra: renderExtra(key, index),
      };
    });
    return (
      <Card
        title={renderTitle()}
        style={{ display: tab === 'Project' ? '' : 'none' }}
      >
        <Collapse items={items} />
      </Card>
    );
  };

  const renderUser = () => {
    return (
      <div style={{ display: tab === 'User' ? '' : 'none' }}> 建设中....</div>
    );
  };

  const renderProxy = () => {
    return (
      <div style={{ display: tab === 'Proxy' ? '' : 'none' }}>
        {selectedPath ? (
          proxyStarted ? (
            <CSSTransition key="content" timeout={300} classNames="fade">
              <Col>
                <>
                  <Card title="Devtools-Proxy-Preview">
                    <Card
                      type="inner"
                      title="项目信息："
                      style={{ marginBottom: '20px' }}
                    >
                      <Paragraph>
                        <strong>项目名称：</strong>{' '}
                        {selectedProject
                          ? selectedProject?.name
                          : '暂无项目名称'}
                      </Paragraph>
                      <Paragraph>
                        <strong>项目描述：</strong>{' '}
                        {selectedProject
                          ? selectedProject.description
                          : '暂无项目描述'}
                      </Paragraph>
                      <Alert
                        message="Proxy启动成功"
                        type="success"
                        showIcon
                        style={{ marginTop: '20px' }}
                      />
                    </Card>
                    <Card type="inner">
                      <ConfigFileViewer
                        fileContent={fileContent}
                        configFilePath={configFilePath}
                        onReboot={onReboot} // 传递重启回调
                        tempCommandJson={tempCommandJson}
                        selectedProject={selectedProject}
                      />
                    </Card>
                  </Card>
                </>
              </Col>
            </CSSTransition>
          ) : (
            <CSSTransition key="loading" timeout={300} classNames="fade">
              <Col
                style={{
                  width: '100%',
                  height: '100%',
                  display: 'flex', // 使用Flex布局
                  justifyContent: 'center', // 水平居中
                  alignItems: 'center', // 垂直居中
                  flexDirection: 'column', // 子元素垂直排列
                }}
              >
                <Spin
                  size="large"
                  tip={`正在为您开启 ${selectedProject?.name} 项目的代理...`} // 动态提示文本
                  style={{ marginTop: '20px' }}
                />
              </Col>
            </CSSTransition>
          )
        ) : (
          <CSSTransition
            style={{ width: '100%', height: '100%' }}
            key="empty"
            timeout={300}
            classNames="fade"
          >
            <Card
              title={
                <Space>
                  {renderTitle()}
                  <Button
                    type={proxyStarted ? 'danger' : 'primary'}
                    icon={
                      proxyStarted ? (
                        <StopOutlined
                          style={{
                            color: '#ffffff',
                          }}
                        />
                      ) : (
                        <CaretRightOutlined
                          style={{
                            color: '#ffffff',
                          }}
                        />
                      )
                    }
                    onClick={() => {
                      if (proxyStarted) {
                        closeWebSocket();
                      } else {
                        handleRunCommand(selectedProject);
                      }
                    }}
                    style={{
                      transition: 'transform 0.3s',
                      outline: 'none',
                      backgroundColor: proxyStarted ? '#ff4d4f' : '#4096ff',
                      borderColor: proxyStarted ? '#ff4d4f' : '#4096ff',
                    }}
                  >
                    启动代理
                  </Button>
                </Space>
              }
            >
              <Empty
                image={Empty.PRESENTED_IMAGE_SIMPLE}
                description="请选择相关项目启动Proxy"
                style={{ marginTop: '20px' }}
              />
            </Card>
          </CSSTransition>
        )}
      </div>
    );
  };

  if (!selectedProject) {
    return (
      <CSSTransition
        style={{
          width: '100%',
          height: '100%',
          display: tab === 'Project' ? '' : 'none',
        }}
        key="empty"
        timeout={300}
        classNames="fade"
      >
        <Card>
          <Empty
            image={Empty.PRESENTED_IMAGE_SIMPLE}
            description="请选择项目"
            style={{ marginTop: '20px' }}
          />
        </Card>
      </CSSTransition>
    );
  }
  return (
    <TransitionGroup>
      {renderProject()}
      {renderProxy()}
      {renderUser()}
    </TransitionGroup>
  );
};

export default ProxyContent;
