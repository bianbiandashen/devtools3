import React, { useState, useEffect } from 'react';
import {
  Button,
  Input,
  Space,
  Typography,
  Row,
  Col,
  notification,
  Tooltip,
  Card,
  Modal,
  Tabs,
} from 'antd';
import { join } from '@tauri-apps/api/path';
import { writeTextFile } from '@tauri-apps/api/fs';
import { invoke } from '@tauri-apps/api/tauri';
import {
  FolderOpenOutlined,
  DeleteOutlined,
  CheckCircleTwoTone,
  CloseCircleTwoTone,
  QuestionCircleOutlined,
  CodeOutlined,
  CheckCircleOutlined,
} from '@ant-design/icons';
import { listen } from '@tauri-apps/api/event';
import {
  selectFolder,
  readPackageJson,
  savePackageConfig,
  clearPackageConfigCache,
  checkPort7777,
  checkSystemProxy,
  readConfigFile,
  readPackageConfigCache,
  closePort7777,
  loop,
} from '../../../utils';
import DirectoryList from '../components/DirectoryList';
import ProxyContent from '../components/ProxyContent';
import styles from './ProxyConfig.module.css';
import { uniqBy } from 'lodash-es';
import { useFolderContext } from '@/hooks/useFolders';

const { Title } = Typography;

function App() {
  const [directories, setDirectories] = useState([]);
  const [fileContent, setFileContent] = useState('');
  const [selectedPath, setSelectedPath] = useState(null);
  const [configFilePath, setConfigFilePath] = useState('');
  const [loading, setLoading] = useState(false);
  const [proxyStarted, setProxyStart] = useState(false);
  const [systemStart, setSystemStart] = useState(false);
  const [selectedProject, setSelectedProject] = useState(null);
  const [runnningItem, setRunningItem] = useState(null);
  const [tempCommandJson, setTempCommandJson] = useState(null);
  const [commandOutput, setCommandOutput] = useState('');
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [checkCommand, setCheckCommand] = useState('');
  const { folders, setFolders } = useFolderContext();
  const { folderName, folderList } = folders;
  const [password, setPassword] = useState('');
  const [tab, setTab] = useState('Project');
  const [isPasswordModalVisible, setIsPasswordModalVisible] = useState(false);

  const checkProxy = async () => {
    const res = await checkPort7777();
    if (res) {
      const { working_directory } = res;
      setProxyStart(true);
      setSelectedPath(working_directory);
    } else {
      setProxyStart(false);
    }
  };

  useEffect(() => {
    const project = folderList?.find(item => item.path === selectedPath);
    setSelectedProject(project);
    if (selectedPath) {
      readConfigFile(selectedPath, setFileContent, setConfigFilePath);
    }
  }, [selectedPath, folderList]);

  useEffect(() => {
    checkProxy();
    checkSystemProxy(setSystemStart);
    const interval = loop(() => {
      checkProxy();
      checkSystemProxy(setSystemStart);
    }, 5000);

    readPackageConfigCache().then(res => {
      setDirectories(res);
      if (res) {
        setFolders(prev => {
          return {
            ...prev,
            folderList:
              res?.map(item => ({
                ...item,
                label: item.name,
                key: item.name,
              })) || [],
          };
        });
      }
    });

    // 订阅 command-output 和 command-complete 事件
    const unlistenOutput = listen('command-output', event => {
      setCommandOutput(prevOutput => prevOutput + event.payload + '\n');
    });

    const unlistenComplete = listen('command-complete', event => {
      setCommandOutput(prevOutput => prevOutput + event.payload + '\n');
    });

    return () => {
      clearInterval(interval);
      // 取消订阅事件
      unlistenOutput.then(fn => fn());
      unlistenComplete.then(fn => fn());
    };
  }, []);

  const closeWebSocket = async () => {
    invoke('disable_proxy');
    closePort7777();
    setSelectedPath(null);
    await checkProxy();
    await checkSystemProxy(setSystemStart);
  };

  const runCommand = async (path, command) => {
    try {
      const output = await invoke('exec_spawn_command', {
        path,
        command,
      });
      setSelectedPath(path);
      await readConfigFile(path, setFileContent, setConfigFilePath);
    } catch (error) {
      notification.error({
        message: 'Error executing command',
        description: `Error: ${error}`,
      });
    }
  };

  const handleRunCommand = async item => {
    console.log('handleRunCommand called with item:', item);

    try {
      await checkProxy();
      setLoading(true);

      await runCommand(item.path, item.scripts.devtools);
      setTempCommandJson(null);
      notification.success({
        message: `执行成功：开始执行proxy`,
        description: `${item.path}`,
      });
    } catch (error) {
      console.error('Error in handleRunCommand:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectProject = project => {
    setSelectedProject(project);
  };

  const openInVSCode = async path => {
    try {
      await invoke('open_in_vscode', { path });
    } catch (error) {
      console.error('Failed to open in VSCode:', error);
    }
  };

  const onReboot = async (item, tempCommandJson) => {
    try {
      const filePath = await join(item.path, 'tempDevtools.json.js');
      await writeTextFile(filePath, tempCommandJson);
      closeWebSocket();

      notification.success({
        message: `开始重启proxy`,
        description: `${filePath}`,
      });
      setTimeout(() => {
        runCommand(
          item.path,
          item.scripts.devtools.replace(
            './devtool.config.js',
            './tempDevtools.json.js',
          ),
        );
        setTempCommandJson(tempCommandJson);
      }, 2000);
    } catch (error) {
      console.error('Error creating file:', error);
    }
  };

  const checkDevtoolInstalled = async () => {
    try {
      const dirpath = await invoke('get_current_dir');
      const output = await invoke('exec_spawn_command', {
        path: dirpath,
        command: 'which devtool',
      });
      if (output) {
        notification.info({
          message: `安装情况请查看右侧【命令行输出】`,
          description: ``,
        });
      }
    } catch (error) {}
  };

  useEffect(() => {
    return () => {
      closeWebSocket();
    };
  }, []);

  const getHighlightedOutput = text => {
    const regex = /proxy plugin start!/g;
    const parts = text.split(regex);
    return parts.reduce((prev, curr, i) => {
      if (!i) {
        return [curr];
      }
      return prev.concat(
        <span key={i} style={{ color: 'green', fontWeight: 'bold' }}>
          proxy plugin start!
        </span>,
        curr,
      );
    }, []);
  };

  const installGlobalPackage = async () => {
    setIsPasswordModalVisible(true);
  };

  const handlePasswordOk = async () => {
    setIsPasswordModalVisible(false);
    try {
      const devtoolVersion = await invoke('install_modular_startup', {
        password,
      });
      notification.success({
        message: '安装成功',
        description: `@xhs/modular-startup 已全局安装 版本为 ${devtoolVersion}`,
      });
    } catch (error) {
      notification.error({
        message: '安装失败',
        description: `Error: ${error}`,
      });
    }
  };

  const installBrewPackage = async () => {
    try {
      await invoke('install_homebrew');
      notification.success({
        message: '安装成功',
        description: '@install_homebrew 已全局安装',
      });
    } catch (error) {
      notification.error({
        message: '安装失败',
        description: `Error: ${error}`,
      });
    }
  };

  const handleOk = () => {
    setIsModalVisible(false);
  };

  const handleCancel = () => {
    setIsModalVisible(false);
  };

  const handleSudoCancel = () => {
    setIsPasswordModalVisible(false);
  };
  const installNodeNpm = async () => {
    try {
      const response = await invoke('install_node_npm'); // Adjust this invoke to match your backend function name
      notification.success({
        message: '安装成功',
        description: response,
      });
    } catch (error) {
      notification.error({
        message: '安装失败',
        description: `Error: ${error}`,
      });
    }
  };

  const handleCheckCommand = async () => {
    if (!checkCommand) {
      notification.error({
        message: '请输入要检查的命令',
      });
      return;
    }

    try {
      const dirpath = await invoke('get_current_dir');
      const response = await invoke('exec_spawn_command', {
        command: `${checkCommand} `,
        path: dirpath,
      });
      notification.success({
        message: `${checkCommand} 安装检测`,
        description: response,
      });
    } catch (error) {
      notification.error({
        message: '检测失败',
        description: `Error: ${error}`,
      });
    }
  };

  const renderLeft = () => {
    return (
      <Col span={6}>
        <div className={styles.proxyConfig}>
          <DirectoryList
            directories={folderList}
            loading={loading}
            handleRunCommand={handleRunCommand}
            closeWebSocket={closeWebSocket}
            openInVSCode={openInVSCode}
            setSelectedPath={setSelectedPath}
            onSelect={handleSelectProject}
            proxyStarted={proxyStarted}
          />
        </div>
      </Col>
    );
  };

  const renderRightContent = content => {
    return (
      <div className={styles.proxyConfig}>
        <ProxyContent
          onReboot={onReboot}
          runnningItem={runnningItem}
          directories={folderList}
          loading={loading}
          tempCommandJson={tempCommandJson}
          fileContent={fileContent}
          configFilePath={configFilePath}
          handleRunCommand={handleRunCommand}
          closeWebSocket={closeWebSocket}
          openInVSCode={openInVSCode}
          selectedPath={selectedPath}
          selectedProject={selectedProject}
          onSelect={handleSelectProject}
          proxyStarted={proxyStarted}
          tab={tab}
        />
      </div>
    );
  };

  const renderRightLabel = ({ label }) => {
    return (
      <Space>
        {label}
        {/* <CheckCircleOutlined /> */}
      </Space>
    );
  };

  const renderRight = () => {
    const items = [
      {
        key: 'Project',
        label: renderRightLabel({
          label: '项目',
        }),
        // children: renderRightContent(1111),
      },
      {
        key: 'Proxy',
        label: renderRightLabel({
          label: '代理',
        }),
        // children: renderRightContent(222),
      },
      {
        key: 'User',
        label: renderRightLabel({
          label: '账号',
        }),
        // children: renderRightContent(3333),
      },
    ];
    return (
      <Col span={18}>
        <Row style={{ minHeight: '60vh' }}>
          <Col span={22} style={{ paddingRight: 8 }}>
            {renderRightContent()}
          </Col>
          {!!selectedProject && (
            <Col span={2}>
              <Tabs
                items={items}
                tabPosition={'right'}
                content=""
                onChange={setTab}
              />
            </Col>
          )}
        </Row>
      </Col>
    );
  };

  const renderHeader = () => {
    return (
      <>
        <Row justify="end"></Row>
        <Row justify="space-between">
          <Col span={6} style={{ paddingRight: 6 }}>
            <Title
              level={2}
              style={{ textAlign: 'center', marginBottom: '20px' }}
            >
              DevTools 项目管理
            </Title>
            <Space
              direction="vertical"
              size="large"
              style={{ width: '100%', marginBottom: '20px' }}
            >
              <Row gutter={12}>
                <Col span={12}>
                  <Button
                    type="primary"
                    block
                    size="large"
                    icon={<FolderOpenOutlined />}
                    onClick={async () => {
                      const path = await selectFolder();
                      if (path) {
                        const result = await readPackageJson(path);

                        setFolders(prev => {
                          return {
                            ...prev,
                            folderList: uniqBy(
                              [...result, ...(folderList || [])],
                              'name',
                            ).map(item => ({
                              ...item,
                              label: item.name,
                              key: item.name,
                            })),
                          };
                        });
                        await savePackageConfig(
                          result && JSON.stringify(result),
                        );
                      }
                    }}
                  >
                    选择文件夹
                  </Button>
                </Col>
                <Col span={12}>
                  <Button
                    type="default"
                    block
                    size="large"
                    icon={<DeleteOutlined />}
                    onClick={() => {
                      clearPackageConfigCache();
                      setFolders(prevConfig => {
                        return {
                          ...prevConfig,
                          folderList: [],
                        };
                      });
                      setFileContent('');
                      setSelectedPath(null);
                      setConfigFilePath('');
                      setCommandOutput('');
                    }}
                  >
                    清空
                  </Button>
                </Col>
              </Row>
            </Space>
          </Col>
          <Col
            span={16}
            style={{ textAlign: 'right', alignSelf: 'end', marginBottom: 24 }}
          >
            <Button
              type="primary"
              onClick={() => {
                notification.info({
                  message: '安装中',
                  description: '正在安装@xhs/modular-startup，请稍后...',
                });
                const timer = setTimeout(() => {
                  clearTimeout(timer);
                  handlePasswordOk();
                }, 300);
              }}
              icon={<QuestionCircleOutlined />}
              style={{ marginLeft: '8px' }}
            >
              检查devtool版本
            </Button>

            <Button
              type="primary"
              onClick={() => {
                setIsModalVisible(true);
              }}
              icon={<CodeOutlined />}
              style={{ marginLeft: '8px' }}
            >
              iTerm
            </Button>
          </Col>
        </Row>
      </>
    );
  };

  return (
    <div
      style={{
        padding: '20px',
        width: '100%',
        height: '100%',
        margin: '0 auto',
      }}
    >
      {renderHeader()}
      <Row gutter={12}>
        {renderLeft()}
        {renderRight()}
      </Row>

      <Modal
        title="请输入sudo密码"
        visible={isPasswordModalVisible}
        onOk={handlePasswordOk}
        onCancel={handleSudoCancel}
      >
        <Input.Password
          placeholder="sudo 密码"
          value={password}
          onChange={e => setPassword(e.target.value)}
        />
      </Modal>
      <Modal
        title="Command Output"
        visible={isModalVisible}
        onOk={handleOk}
        onCancel={handleCancel}
        footer={[
          <Button key="close" onClick={handleCancel}>
            关闭
          </Button>,
        ]}
        style={{ top: 20 }}
        bodyStyle={{ maxHeight: '600px', overflowY: 'auto' }}
      >
        <Input
          style={{ width: '160px', marginRight: '8px', marginBottom: '8px' }}
          placeholder="请输入命令"
          value={checkCommand}
          onChange={e => setCheckCommand(e.target.value)}
        />
        <Button
          type="primary"
          onClick={handleCheckCommand}
          icon={<QuestionCircleOutlined />}
          style={{ marginBottom: '16px' }}
        >
          检测命令
        </Button>
        <Card
          style={{
            backgroundColor: '#1e1e1e',
            color: '#d4d4d4',
            fontFamily: 'monospace',
            padding: '16px',
            borderRadius: '8px',
            boxShadow: '0 0 15px rgba(0, 0, 0, 0.2)',
          }}
        >
          <pre
            style={{
              whiteSpace: 'pre-wrap',
              wordWrap: 'break-word',
            }}
          >
            {getHighlightedOutput(commandOutput)}
          </pre>
        </Card>
      </Modal>
    </div>
  );
}

export default App;
