import { Link, Outlet, useNavigate } from '@modern-js/runtime/router';
import hotkeys from 'hotkeys-js';
import '@/styles/index.css';
import React, { useState, useEffect, useContext, useRef } from 'react';
import {
  Typography,
  Layout as AntLayout,
  Menu,
  ConfigProvider,
  Flex,
  App,
  Button,
  Dropdown,
} from 'antd';
import { RedIcon } from '@/assests';
import ExportIconWithTooltip from '@/components/ExportIconWithTooltip';
import { menuConfig } from '@/config/menu.config';
import '@/styles/layout.less';
import { invoke } from '@tauri-apps/api/tauri';
import Login from '../components/Login';
import {
  readPackageConfigCache,
  readPackageJson,
  savePackageConfig,
  selectFolder,
} from '@/utils';
import { uniqBy } from 'lodash-es';
import { FolderProvider, useFolderContext } from '@/hooks/useFolders';

const { Header, Content, Sider } = AntLayout;
const { Title } = Typography;

const initializeAsgard = () => {
  // const app = new Asgard({
  //   routers: menuConfig,
  // });
  // AsgardTracker.install(null, null, {
  //   appId: 12,
  //   getUserInfo: async () => {
  //     return Promise.resolve({
  //       userId: 'xxx',
  //       groupUserId: 'xxx',
  //     });
  //   },
  //   logger: process.env.BUILD_ENV !== 'production',
  // });
};

// 检查端口 7777 的函数
const checkPort7777AndNavigate = async (navigate: any, intervalId: number) => {
  try {
    const response = await invoke('check_port');
    console.log('check_port', response);
    if (response) {
      clearInterval(intervalId);
      navigate('/dev-proxy/list');
    }
  } catch (error) {
    console.error('Failed to check port 7777:', error);
  }
};

const Layout: React.FC = () => {
  const [collapsed, setCollapsed] = useState(true);
  const { folders, setFolders } = useFolderContext();
  const { folderName, folderList } = folders;
  const navigate = useNavigate();

  useEffect(() => {
    initializeAsgard();

    // 轮询调用 checkPort7777AndNavigate 每隔 5 秒
    const intervalId: any = setInterval(() => {
      checkPort7777AndNavigate(navigate, intervalId);
    }, 5000);

    // 清除定时器
    return () => clearInterval(intervalId);
  }, [navigate]);

  hotkeys.filter = function () {
    return true;
  };

  // 创建临时文件并读取内容的方法
  const handleCreateAndReadTempFile = async () => {
    try {
      const data = [
        { name: 'Item 1', value: 'Value 1' },
        { name: 'Item 2', value: 'Value 2' },
      ];

      // 调用 create_temp_file_with_list 方法
      const tempFilePath = await invoke('create_temp_file_with_list', {
        data,
      });
      console.log('Temporary file created at:', tempFilePath);

      // 调用 read_temp_file 方法
      const fileData = await invoke('read_temp_file', {
        filePath: tempFilePath,
      });
      console.log('Data from temp file:', fileData);
    } catch (error) {
      console.error('Error creating or reading temp file:', error);
    }
  };

  return (
    <ConfigProvider
      theme={{
        components: {
          Layout: {
            triggerBg: '#fff',
            triggerColor: '#002140',
            headerBg: '#fff',
          },
        },
      }}
    >
      <App>
        <AntLayout className="w-screen min-h-screen global-layout">
          <Header className="border-0 border-b border-gray-300 border-solid flex items-center">
            <Flex justify="space-between" align="center" className="w-full">
              <Link to="/">
                <Flex gap="12px" justify="center" align="center">
                  {/* <RedIcon /> */}
                  <Title level={5} className="m-0">
                    DevTools
                  </Title>
                </Flex>
              </Link>
              <span className="ml-4 flex items-center md:ml-6">
                <Dropdown.Button
                  menu={{
                    items: folderList,
                    onClick: () => {},
                  }}
                  className="ml-3"
                  overlayClassName="h-6"
                  placement="bottomRight"
                  icon={<ExportIconWithTooltip />}
                >
                  <span
                    onClick={async () => {
                      const path = await selectFolder();
                      if (path) {
                        const result = await readPackageJson(path);
                        setFolders((prevConfig: any) => {
                          return {
                            ...prevConfig,
                            folderList: uniqBy(
                              [...result, ...(folderList || [])],
                              'name',
                            ).map(item => ({
                              ...item,
                              label: item.name,
                              key: item.name,
                            })),
                          };
                        });
                        await savePackageConfig(
                          result && JSON.stringify(result),
                        );
                      }
                    }}
                  >
                    {folderName || '选择文件夹'}
                  </span>
                </Dropdown.Button>
              </span>
              {/* 添加按钮来触发创建和读取临时文件 */}
              {/* <Button type="primary" onClick={handleCreateAndReadTempFile}>
                Create and Read Temp File
              </Button> */}
            </Flex>
          </Header>
          <AntLayout>
            <Sider
              width={200}
              collapsible
              theme="light"
              collapsed={collapsed}
              collapsedWidth={80}
              onCollapse={value => setCollapsed(value)}
              className="border-0 border-r border-gray-300 border-solid"
            >
              <Menu
                mode="inline"
                defaultSelectedKeys={['1']}
                defaultOpenKeys={['sub1']}
                style={{ height: '100%', borderRight: 0 }}
                items={menuConfig}
                onClick={function (payload) {
                  navigate(payload.key);
                }}
              />
            </Sider>
            <AntLayout>
              <Content>
                <Outlet />
              </Content>
            </AntLayout>
          </AntLayout>
        </AntLayout>
      </App>
    </ConfigProvider>
  );
};

const Wrapper = () => (
  <FolderProvider>
    <Layout />
  </FolderProvider>
);

export default Wrapper;
