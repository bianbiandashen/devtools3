import React from 'react';

const NormalContentLayout: React.FC<{ children: React.ReactNode }> = props => {
  return (
    <div className="p-6 h-full">
      <div className="bg-white p-6 m-0 rounded-lg h-full">{props.children}</div>
    </div>
  );
};

export default NormalContentLayout;
