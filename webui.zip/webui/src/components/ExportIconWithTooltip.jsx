import React, { useState } from 'react';
import { Tooltip, Typography, Modal, Button } from 'antd';
import { DownloadOutlined } from '@ant-design/icons';
import { readPackageConfigCache } from '../utils';
import CodeMirror from '@uiw/react-codemirror';
import 'codemirror/lib/codemirror.css';
import 'codemirror/theme/material.css';

const { Title } = Typography;

const ExportIconWithTooltip = () => {
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [directories, setDirectories] = useState(null);

  const handleClick = async () => {
    const res = await readPackageConfigCache();
    setDirectories(JSON.stringify(res, null, 2));
    setIsModalVisible(true);
  };

  const handleDownload = () => {
    if (!directories) {
      return;
    }
    const element = document.createElement('a');
    const file = new Blob([directories], { type: 'application/json' });
    const url = URL.createObjectURL(file);
    element.href = url;
    element.download = 'config.json';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    URL.revokeObjectURL(url);
  };

  return (
    <>
      <Tooltip title="将proxy过的文件路径及config信息导出成一个json">
        <Title level={5} className="m-0">
          <DownloadOutlined
            style={{ cursor: 'pointer' }}
            onClick={handleClick}
          />
        </Title>
      </Tooltip>
      <Modal
        title="开发仓库数据中心"
        visible={isModalVisible}
        onCancel={() => setIsModalVisible(false)}
        footer={[
          // <Button key="download" type="primary" onClick={handleDownload}>
          //   下载
          // </Button>,
          <Button key="back" onClick={() => setIsModalVisible(false)}>
            关闭
          </Button>,
        ]}
        bodyStyle={{ padding: 0 }}
      >
        <div style={{ height: '300px', overflow: 'auto' }}>
          <CodeMirror
            value={directories}
            options={{
              mode: 'application/json',
              theme: 'material',
              lineNumbers: true,
              readOnly: true,
            }}
            style={{ height: '100%' }}
          />
        </div>
      </Modal>
    </>
  );
};

export default ExportIconWithTooltip;
