// components/Login.tsx
import React from 'react';
import useLogin from '../hooks/useLogin';

const Login: React.FC = () => {
  useLogin();
  return null; // 登录过程中不需要渲染任何内容
};

export default Login;
