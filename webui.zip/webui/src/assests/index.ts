export { default as RedIcon } from './redIcon.svg';
