module.exports = {
  proxy: {
    enable: true,
    list: [
      // /** 微前端子应用 */
      // {
      //   sourcePattern:
      //     /^http(s?):\/\/ark((-.+\.sl)?\.(sit|beta))?\.xiaohongshu\.com\/formula-static\/ark-app-order\/public\//,
      //   targetUrl: 'http://127.0.0.1:4007/',
      // },
      // {
      //   sourcePattern:
      //     /^http(s?):\/\/ark((-.+\.sl)?\.(sit|beta))?\.xiaohongshu\.com\/js\/main.bundle.js/,
      //   targetUrl: 'http://127.0.0.1:4007/js/main.bundle.js',
      // },
      // /** 单独应用 */
      // {
      //   sourcePattern:
      //     /^http(s?):\/\/ebill((-.+\.sl)?\.sit|beta)*\.xiaohongshu\.com\/((?!api).*)/,
      //   targetUrl: 'http://127.0.0.1:1388/$4',
      // },
      // /** for 小红书app */
      // {
      //   sourcePattern: /http(s?):\/\/edith.xiaohongshu.com\/(.*)/,
      //   targetUrl: 'http://edith.sit.xiaohongshu.com/$2',
      // },
      // {
      //   sourcePattern: /http(s?):\/\/www.xiaohongshu.com\/(.*)/,
      //   targetUrl: 'http://www.sit.xiaohongshu.com/$2',
      // },
    ],
  },
  mock: {
    enable: true,
    mockDir: './mock',
  },
};
